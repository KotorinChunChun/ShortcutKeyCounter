# ShortcutKeyCounter v0.1.3 implementation status

## Implemented in this source package

- Runtime Security Gate before Overlay / Realtime Log / DB writer.
- Hard prohibition on persistence of every unmodified keyboard, mouse and wheel input.
- Realtime Log restricted to successfully persisted events.
- UI Automation password focus check and normal-process → elevated-foreground fail-closed boundary.
- MouseX1 / MouseX2 / WheelLeft / WheelRight input identities and full modifier-policy UI.
- Active-window-avoidance Overlay with allowed 3×3 positions; legacy rotation removed.
- Dynamic single-key layout with Work Area wrapping and new-token-only animation.
- Overlay click-through retreat operation and persisted opposite/preferred position.
- SAMPLE preview and fixed-monitor identification preview on the native Overlay path.
- v0.1.3 Overlay default display duration (`1840ms`) while preserving existing custom values.
- Key mapping code/name/label/category columns, multi-filter, modifier-column selection and confirmed bulk edits.
- Production/Test active DB switching across capture/statistics/export/backup/data-management paths.
- Test-only ~10,000-event sample generation using Production DB application/shortcut identities, plus application-usage samples.
- Delete-through-yesterday across event/daily/application-usage aggregates.
- Application foreground-usage daily aggregation with OS last-input idle detection; feature default OFF.
- Dark/Light UI, monitor enumeration/preview/fallback, 3-state Tray visuals.
- Transparent white 3D C-key application/tray icons.

## Validation performed in this build environment

PASS:
- TypeScript strict compilation and emitted `ui/dist` rebuild.
- `tauri.conf.json` JSON parse.
- workspace/application/crate `Cargo.toml` TOML parse.
- SQLite migration execution in an in-memory database, including `application_usage_daily`.
- stale v0.1.2 executable UI labels removed.
- stale v0.1.2 release binaries removed from this modified source package.

Not executable in this environment:
- `cargo fmt`, `cargo check`, `cargo clippy`, `cargo test`, Windows MSVC release build (Rust/Cargo toolchain is unavailable here).
- Win32 hooks, UI Automation, UAC/Integrity Level behavior, Tray, multi-monitor/DPI, horizontal-wheel hardware and Overlay visual acceptance.

Run `scripts/build-release.ps1` on Windows. It performs Rust formatting/check/Clippy/tests/release build before packaging.

## Required release gate

Use `docs/WINDOWS_BUILD_AND_ACCEPTANCE.md`. Do not treat a Windows ZIP/installer as release-ready until the Windows-only security, monitor, DPI, input, Tray and Overlay checks pass.
