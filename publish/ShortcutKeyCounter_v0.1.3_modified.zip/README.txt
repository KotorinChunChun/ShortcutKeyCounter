ShortcutKeyCounter v0.1.3
========================

Windows上のショートカット利用をローカル集計する Rust + Tauri 2 アプリです。

v0.1.3 highlights:
- 修飾なし単独入力はkeyboard/mouse/wheelを問わず永続記録禁止。Overlay用一時処理のみ。
- Realtime LogはDB記録対象イベントだけを表示。
- password/high-integrity foreground等をSecurity GateでOverlay/DBより先に抑止。
- MouseX1/X2、WheelLeft/Rightを含む16修飾パターンのKey Mapping。
- Active-window回避型Native Overlay、許可9位置、折返し、新規tokenのみanimation、SAMPLE preview、click-through退避。
- Production/Test DBをアプリ全体で切替。Sample dataはTest DBだけへ生成。
- Application foreground usage、Light theme、monitor selection/preview、3-state Tray icon。

Build:
  pwsh -ExecutionPolicy Bypass -File .\scripts\build-release.ps1 -SkipInstaller

Data:
  %LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter.db
  %LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter.test.db
  %LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_labels.json
  %LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_policy.json
  %LOCALAPPDATA%\ShortcutKeyCounter\overlay-theme.json

重要:
修飾なし単独入力の記録禁止はRuntime側のSecurity invariantです。UI/JSONを変更しても解除できません。
