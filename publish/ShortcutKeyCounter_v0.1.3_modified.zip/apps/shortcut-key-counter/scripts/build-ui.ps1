$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot = Split-Path -Parent $Here
$UiRoot = Join-Path $AppRoot 'ui'
$Dist = Join-Path $UiRoot 'dist'

if (-not (Get-Command tsc -ErrorAction SilentlyContinue)) {
    throw 'TypeScript compiler (tsc) が見つかりません。Node.js + TypeScriptをインストールしてください。'
}

New-Item -ItemType Directory -Force -Path (Join-Path $Dist 'styles') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Dist 'js') | Out-Null
Copy-Item (Join-Path $UiRoot 'index.html') (Join-Path $Dist 'index.html') -Force
Copy-Item (Join-Path $UiRoot 'styles\main.css') (Join-Path $Dist 'styles\main.css') -Force
& tsc -p (Join-Path $UiRoot 'tsconfig.json')
if ($LASTEXITCODE -ne 0) { throw "TypeScript build failed: $LASTEXITCODE" }
Write-Host '[ShortcutKeyCounter] UI build complete.'
