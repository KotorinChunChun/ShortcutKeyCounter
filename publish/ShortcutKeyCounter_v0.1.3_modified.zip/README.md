# ShortcutKeyCounter v0.1.3

Windows上のショートカット利用をローカル集計する Rust + Tauri 2 デスクトップアプリです。通常文字列、URL、ウィンドウタイトル、ドキュメント名、クリップボード、実行ファイルのフルパスは保存しません。

## v0.1.3 主な実装

- Win32 Low-Level keyboard / mouse hook + Elevated helper。
- 修飾なし単独入力は keyboard / mouse / vertical wheel / horizontal wheel のすべてで永続記録禁止。Overlay用の一時メモリ処理だけを許可。
- Realtime Logは実際にDBへ記録されたイベントだけを表示。
- UI Automationのpassword属性、高Integrity Level foreground等を入力処理前のSecurity Gateで判定し、判定不能時はFail Closed。
- `MouseX1` / `MouseX2` / `WheelLeft` / `WheelRight` を含む全入力identityと16修飾パターン。
- Native Win32 Overlay: active-window回避、許可9位置、動的横幅・キー単位折返し、新規tokenだけのIN animation、click-through退避クリック、SAMPLE preview。
- Overlay既定表示時間は旧既定値から+1秒（`1840ms`）。
- キーマッピング: キーコード / キー名 / Overlay表示名 / 分類 / 16修飾列、複数分類filter、複数列選択、一括変更確認。
- Overlay表示名は `overlay_key_labels.json`、ポリシーは `overlay_key_policy.json` へ永続化。
- Production / Test DBをアプリ全体で切替。Test DB中は常時バッジ表示。
- Sample dataはTest DBだけへ生成し、母集団はProduction DBの実績を読み取る。shortcut約10,000件とapplication usage日次データを生成。
- 前日以前の `shortcut_events` / `shortcut_daily` / `application_usage_daily` を確認付きで削除。
- アプリ別Foreground利用時間（既定OFF）。10秒周期、OSの最終keyboard/mouse入力が1分以上ない間は加算停止。
- Dark / Light theme、実モニター一覧、固定monitor preview、切断時primary monitor fallback。
- Trayは「記録中」「正常理由による停止」「異常停止」の3状態アイコン。

## セキュリティ不変条件

設定UI・JSON・旧設定値よりRuntime Security Gateを優先します。特に修飾なし単独入力は設定を改ざんしてもSQLite、Realtime Log、診断、CSV等へ保存しません。password/credential保護、高権限foreground、計測停止、除外アプリの判定はOverlay/DBより前に適用します。

## プロジェクト構成

- `crates/shortcut-common`: 共通model / IPC protocol / path
- `crates/shortcut-core`: shortcut判定・正規化・重複抑制
- `crates/shortcut-storage`: SQLite、repository、statistics、migration
- `crates/shortcut-windows`: Win32 hook / foreground / user activity / overlay window / elevation / IPC
- `apps/shortcut-key-counter`: Tauriメインアプリ
- `apps/shortcut-key-capture`: 管理者権限アプリ向け入力取得helper
- `scripts`: release / ZIP packaging
- `docs`: Windows build / acceptance
- `dev`: 仕様・検証資料

## Windows build

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\build-release.ps1
```

ZIPだけ作る場合:

```powershell
.\scripts\build-release.ps1 -SkipInstaller
```

個別確認:

```powershell
cargo fmt --all -- --check
cargo check --workspace --all-targets --all-features
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
cargo build --release -p shortcut-key-counter -p shortcut-key-capture
```

Frontend:

```powershell
tsc -p .\apps\shortcut-key-counter\ui\tsconfig.json
```

詳細は `docs/WINDOWS_BUILD_AND_ACCEPTANCE.md` を参照してください。

## データ保存先

```text
%LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter.db
%LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter.test.db
%LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter_key_mapping.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_labels.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_policy.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay-theme.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay\default\key.svg
```

DBは実行ファイル配置先から独立しています。
