use chrono::{Duration, Local, NaiveDateTime, NaiveTime};
use rusqlite::{params, Connection, TransactionBehavior};
use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum SampleDataError {
    #[error("SQLite error: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("sample source has no applications or shortcuts")]
    EmptySource,
}

#[derive(Clone, Debug, Serialize)]
pub struct SampleSourceStatus {
    pub application_count: u64,
    pub shortcut_count: u64,
    pub can_generate: bool,
}

#[derive(Clone, Debug, Serialize)]
pub struct SampleGenerationResult {
    pub events_generated: u64,
    pub usage_rows_generated: u64,
    pub period_start: String,
    pub period_end: String,
}

pub fn source_status(production: &Connection) -> Result<SampleSourceStatus, SampleDataError> {
    let application_count: i64 = production.query_row(
        "SELECT COUNT(*) FROM (SELECT DISTINCT application FROM shortcut_events UNION SELECT DISTINCT application FROM shortcut_daily)",
        [], |row| row.get(0))?;
    let shortcut_count: i64 = production.query_row(
        "SELECT COUNT(*) FROM (SELECT DISTINCT shortcut FROM shortcut_events UNION SELECT DISTINCT shortcut FROM shortcut_daily)",
        [], |row| row.get(0))?;
    Ok(SampleSourceStatus {
        application_count: application_count.max(0) as u64,
        shortcut_count: shortcut_count.max(0) as u64,
        can_generate: application_count > 0 && shortcut_count > 0,
    })
}

pub fn generate_sample_data(
    production: &Connection,
    target: &mut Connection,
    event_count: usize,
) -> Result<SampleGenerationResult, SampleDataError> {
    let applications = distinct_values(production, "application")?;
    let shortcuts = distinct_values(production, "shortcut")?;
    if applications.is_empty() || shortcuts.is_empty() {
        return Err(SampleDataError::EmptySource);
    }
    let yesterday = Local::now().date_naive() - Duration::days(1);
    let start = yesterday - Duration::days(6);
    let tx = target.transaction_with_behavior(TransactionBehavior::Immediate)?;
    let mut rng = Lcg::new(Local::now().timestamp_millis() as u64 ^ 0x5A17_C0DE);
    for _ in 0..event_count {
        let day_offset = rng.range(7) as i64;
        let date = start + Duration::days(day_offset);
        let seconds = rng.range(24 * 60 * 60) as u32;
        let millis = rng.range(1000) as u32;
        let time = NaiveTime::from_num_seconds_from_midnight_opt(seconds, millis * 1_000_000)
            .unwrap_or(NaiveTime::MIN);
        let occurred = NaiveDateTime::new(date, time);
        let application = &applications[rng.range(applications.len() as u64) as usize];
        let shortcut = &shortcuts[rng.range(shortcuts.len() as u64) as usize];
        tx.execute(
            "INSERT INTO shortcut_events(occurred_at, shortcut, application) VALUES (?1, ?2, ?3)",
            params![occurred.format("%Y-%m-%d %H:%M:%S%.3f").to_string(), shortcut, application],
        )?;
        tx.execute(
            "INSERT INTO shortcut_daily(date, shortcut, application, count) VALUES (?1, ?2, ?3, 1)
             ON CONFLICT(date, shortcut, application) DO UPDATE SET count = count + 1",
            params![date.format("%Y-%m-%d").to_string(), shortcut, application],
        )?;
    }

    let mut usage_rows = 0u64;
    for offset in 0..7 {
        let date = start + Duration::days(offset);
        // Keep the aggregate comfortably below 24h/day and add non-uniform variation.
        let daily_budget = 4 * 3600 + rng.range(8 * 3600) as i64;
        let max_apps = applications.len().clamp(1, 12);
        let mut remaining = daily_budget;
        for index in 0..max_apps {
            if remaining <= 0 { break; }
            let applications_left = (max_apps - index) as i64;
            let fair_share = (remaining / applications_left).max(60);
            let seconds = (60 + rng.range(fair_share.max(61) as u64) as i64).min(remaining);
            let app = &applications[(index + rng.range(applications.len() as u64) as usize) % applications.len()];
            tx.execute(
                "INSERT INTO application_usage_daily(date, application, active_seconds) VALUES (?1, ?2, ?3)
                 ON CONFLICT(date, application) DO UPDATE SET active_seconds = active_seconds + excluded.active_seconds",
                params![date.format("%Y-%m-%d").to_string(), app, seconds],
            )?;
            remaining -= seconds;
            usage_rows += 1;
        }
    }
    tx.commit()?;
    Ok(SampleGenerationResult {
        events_generated: event_count as u64,
        usage_rows_generated: usage_rows,
        period_start: start.format("%Y-%m-%d").to_string(),
        period_end: yesterday.format("%Y-%m-%d").to_string(),
    })
}

fn distinct_values(connection: &Connection, column: &str) -> Result<Vec<String>, rusqlite::Error> {
    let sql = format!(
        "SELECT DISTINCT {column} FROM (SELECT {column} FROM shortcut_events UNION ALL SELECT {column} FROM shortcut_daily) WHERE {column} <> '' ORDER BY {column}"
    );
    let mut statement = connection.prepare(&sql)?;
    let rows = statement.query_map([], |row| row.get::<_, String>(0))?;
    rows.collect()
}

struct Lcg(u64);
impl Lcg {
    fn new(seed: u64) -> Self { Self(seed.max(1)) }
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        self.0
    }
    fn range(&mut self, upper: u64) -> u64 { if upper == 0 { 0 } else { self.next() % upper } }
}
