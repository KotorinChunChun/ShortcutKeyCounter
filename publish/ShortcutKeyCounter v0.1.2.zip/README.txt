ShortcutKeyCounter v0.1.2
=======================
Windows上で Ctrl / Alt / Win を含むショートカットキーと対象マウス操作の使用回数を、ローカルSQLiteへ記録・集計する常駐アプリです。

起動:
  手動起動は ShortcutKeyCounter.exe を実行してください（UIを表示します）。
  Windowsログオン自動起動では ShortcutKeyCounter.exe -hide を使用し、UIを生成せず通知領域だけで開始します。
  ウィンドウを×で閉じるとUI WebViewを破棄してメモリを解放し、計測バックエンドだけを継続します。
  通知領域のアイコンをダブルクリックするとUIを新しく生成して再表示します。

データ保存先:
  %LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter.db
  %LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter_key_mapping.json

プライバシー:
  通常文字列、URL、ウィンドウタイトル、ドキュメント名は保存しません。
  アクティブアプリは実行ファイル名のみ保存します。
  統計データを外部送信する機能はありません。

管理者権限アプリ:
  設定から有効化すると、入力取得専用の ShortcutKeyCapture.exe だけをUAC昇格します。
  通常権限Hookは停止せず、Elevated helperを追加経路として併用します。UIとDB処理は通常ユーザー権限のままです。

リアルタイムログ:
  正規化ショートカット、実行ファイル名、記録判定だけをメモリ上に最大500件表示します。

キーマッピング:
  検知対象キー/マウス入力を画面でON/OFFでき、JSONとして保存・出力できます。

ショートカットオーバーレイ (v0.1.2):
  設定でONにすると、入力キーをアクティブウィンドウのあるモニターへ表示します。
  表示時間、最大行数、固定9位置/自動位置、背景色、IN/OUTアニメーションを設定できます。
  通常の単独キーは既定で表示のみ、従来のショートカットは表示して記録します。
  OverlayはWin32ネイティブ描画で、追加WebView2は使用しません。
  表示名: %LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_labels.json
  表示ポリシー: %LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_policy.json
  デザイン設定: %LOCALAPPDATA%\ShortcutKeyCounter\overlay-theme.json
  SVG: %LOCALAPPDATA%\ShortcutKeyCounter\overlay\default\

データ管理:
  CSVとDBバックアップはDownloadsフォルダーへ出力します。保存完了通知から保存フォルダーを開けます。
  「全データ削除」は使用統計だけを削除し、設定と除外アプリ一覧は保持します。

作者: KotoriChun
GitHub: https://github.com/KotorinChunChun/ShortcutKeyCounter
