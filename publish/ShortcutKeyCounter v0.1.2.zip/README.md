# ShortcutKeyCounter v0.1.2

Windows上で `Ctrl` / `Alt` / `Win` を含むショートカット利用をローカル集計する、Rust + Tauri 2 デスクトップアプリです。
通常文字列、URL、ウィンドウタイトル、ドキュメント名、クリップボード、実行ファイルのフルパスは保存しません。

## 実装済み

- Win32 Low-Level keyboard / mouse hook
- shortcut eligibility / 正規化 / key repeat抑制 / 1秒重複抑制
- foreground executable basename取得、除外アプリの即時反映
- SQLite / WAL、event + dailyの同一transaction記録、7日event retention
- Tauri 2 UI（Dashboard / 日刊ランキング / 累計キー別ランキング / アプリ別ランキング / キー×アプリ見取り図 / Shortcut Detail / Realtime Log / Key Mapping / Excluded Apps / Data / Settings / Help）
- 計測ON/OFF（非永続、再起動時ON）
- System Tray、通知領域アイコンのダブルクリック再表示、Windows named Mutex + activation EventによるSingle Instance
- UIは必要時だけWebViewを生成し、Close時はWebViewをdestroyしてメモリを解放
- Windows自動起動（`ShortcutKeyCounter.exe -hide`。自動起動時はWebViewを生成しない）
- Realtime Log（最大500件のメモリリングバッファ、通常文字列なし）
- キーマッピングのJSON永続化・即時反映・DownloadsへのJSON出力
- CSV export（UTF-8 BOM）/ SQLite Online Backup / usage data全削除
- CSV/DB/JSON保存完了通知から既定ファイラで保存フォルダーを開く
- `ShortcutKeyCapture.exe` のUAC起動、token付きNamed Pipe handshake、通常Hook + Elevated helper併用、helper切断時もlocal継続
- ZIP packaging / Inno Setup installer / アンインストール時データ保持・削除選択


## v0.1.2 ショートカットオーバーレイ

- ショートカット検知時、Foreground Windowがあるモニターの作業領域中央下にネイティブOverlayを表示
- Tauri/WebView2を追加せず、Win32 Layered Windowを1個だけ再利用
- 表示時間、最大1〜10行、固定9位置/自動位置、背景色・透明度、IN/OUTアニメーションを設定可能
- 通常の単独キーも表示候補にし、既定は表示のみ。従来のショートカットは表示して記録
- 単独キーは700ms以内の連続入力を最大20トークンまで同一行へ連結
- Overlayが空の間はanimation timerを停止し、Capture側はbounded queueへ`try_send`するだけ
- DB用1秒DuplicateGuardより前にOverlayへ通知するため、実際に連続入力した同一shortcutは表示上は別々に見える
- Local/Elevatedで同じ物理入力を二重取得した場合だけ、shortcut+application+別source+50ms以内でOverlay専用dedup
- `WS_EX_NOACTIVATE` / click-throughで入力フォーカスやマウス操作を奪わない
- Per-monitor DPIとForeground Windowのmonitor移動に追従
- SVGは初回に `%LOCALAPPDATA%\ShortcutKeyCounter\overlay\default\` へ生成し、キー形状を差し替え可能
- 表示名は `%LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_labels.json` で変更可能。DB内部キー名には影響しない
- animation/size/位置は `%LOCALAPPDATA%\ShortcutKeyCounter\overlay-theme.json` で変更可能
- 表示/記録ポリシーは `%LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_policy.json` で変更可能
- 設定画面・通知領域メニューからOverlay ON/OFF、JSONを開く、SVGフォルダーを開く、再読み込みが可能
- Overlayの初期化・描画失敗はOverlayだけを停止し、Capture/DB処理は継続

設計詳細は `dev/ShortcutKeyCounter_v0.1.1_Overlay_Design.md` を参照してください。

## プロジェクト構成

- `crates/shortcut-common`: 共通model / IPC protocol / path
- `crates/shortcut-core`: shortcut判定・正規化・重複抑制
- `crates/shortcut-storage`: SQLite、repository、statistics、migration
- `crates/shortcut-windows`: Win32 hook / foreground / autostart / power / elevation / IPC
- `apps/shortcut-key-counter`: Tauriメインアプリ
- `apps/shortcut-key-capture`: 管理者権限アプリ向け入力取得helper
- `installer`: Inno Setup
- `scripts`: release / ZIP packaging
- `docs`: Windows build / acceptance
- `dev/reference`: 実装基準となった仕様・UIモック

## 2026-08-16 デバッグ実行エラー修正

Tauri commandからDB APIを呼び出す際は、`&db_lock(&state)?` を直接渡さず、必ず次の形式で `MutexGuard` を一度変数へ束縛します。

```rust
let db = db_lock(&state)?;
command_api::dashboard_summary(&db, start, end)
```

この修正は統計・除外アプリ・設定・CSV・DBバックアップ系commandへ反映済みです。`scripts/build-release.ps1` は禁止パターン `&db_lock(&state)?` が残っていればビルド前に停止します。

## Windows build

この配布ソースでは依存関係追加後の古い `Cargo.lock` を同梱せず、リリーススクリプトの `cargo generate-lockfile` で現在のmanifestから再生成します。

```powershell
pwsh -ExecutionPolicy Bypass -File .\scripts\build-release.ps1
```

ZIPだけ作る場合、またはInno Setup未導入環境では:

```powershell
pwsh -ExecutionPolicy Bypass -File .\scripts\build-release.ps1 -SkipInstaller
```

詳細は `docs/WINDOWS_BUILD_AND_ACCEPTANCE.md` を参照してください。

## 開発確認

```powershell
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
cargo build --release -p shortcut-key-counter -p shortcut-key-capture
```

WebViewの破棄・再生成はrelease build後に次で自動検査できます。

```powershell
.\scripts\test-webview-lifecycle.ps1
```

FrontendのTypeScriptは次で検査できます。

```powershell
tsc -p .\apps\shortcut-key-counter\ui\tsconfig.json
```

## データ保存先

```text
%LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter.db
%LOCALAPPDATA%\ShortcutKeyCounter\logs\
%LOCALAPPDATA%\ShortcutKeyCounter\ShortcutKeyCounter_key_mapping.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay_key_labels.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay-theme.json
%LOCALAPPDATA%\ShortcutKeyCounter\overlay\default\key.svg
```

ZIP/installerを更新してもDBは実行ファイル配置先から独立しています。通常アンインストールではデータを保持し、アンインストーラーのチェックを選んだ場合だけローカルデータを削除します。


## Help metadata

作者表示とGitHubリンクは `apps/shortcut-key-counter/src/app_info.rs` に集約しています。現在は `KotoriChun` / `https://github.com/KotorinChunChun/ShortcutKeyCounter` を設定済みです。

## 2026-08-16 UI / Elevated / startup update

- アプリアイコンを白い立体キーの `C` 1キーへ変更。
- ランキングを2階層ナビゲーションへ再編し、日別・累計キー別・アプリ別・リアルタイム・キー×アプリ見取り図を追加。
- Elevated ONでも通常権限Hookを停止しない。helperは追加Capture経路として併用し、既存DuplicateGuardで二重記録を抑制する。
- Elevated OFF時のPipe cleanup/joinは別threadへ退避し、UI commandを同期blockしない。
- Tray/UIの計測ON/OFFは `capture-state-changed` Tauri eventで即時同期する。
- 手動起動はUI表示、Windowsログオン自動起動だけ `-hide` でtray-only。
- 2個目の起動はnamed Mutexでbackend二重起動を防ぎ、activation Eventで既存processの設定画面を表示する。

- リアルタイムログ（入力検知イベントごとに即時更新）
- ダーク/ライトテーマ切替（SQLite設定へ永続化）
