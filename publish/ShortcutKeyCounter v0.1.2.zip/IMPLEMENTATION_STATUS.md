# ShortcutKeyCounter v0.1.1 implementation status

## Implemented in this source package

- Rust workspace backend and Win32 input hooks
- SQLite/WAL persistence, migrations, retention, statistics
- live exclusion state reload
- Tauri 2 application state and command boundary
- TypeScript UI based on the supplied mock plus 日別/累計キー/アプリ/リアルタイム/キー×アプリの二階層ランキング、Key Mapping、Help screens
- manual-launch UI / `-hide` logon tray-only startup / tray double-click reopen / lazy WebView recreation / close-to-destroy / Windows named Mutex single-instance activation
- elevated `ShortcutKeyCapture.exe` with UAC and token-authenticated Named Pipe; local hook remains active, helper is an additional source, disconnect/disable cleanup is nonblocking
- realtime in-memory capture decision log
- persisted key mapping with JSON export and live capture filtering
- CSV / SQLite backup / usage-data delete with open-folder action
- ZIP packaging / Inno Setup installer / uninstall data choice
- release and acceptance scripts/documents
- Tauri command DB lock E0308 fix: bind `MutexGuard<Connection>` to `db` before passing `&db` into `command_api`
- release-script regression gate rejects direct `&db_lock(&state)?` usage


## 2026-08-16 debug-run regression fix

The prior debug-run report identified 15 direct `&db_lock(&state)?` call sites that could fail with E0308 (`expected Connection, found MutexGuard`). This package now binds the guard first (`let db = db_lock(&state)?;`) and passes `&db` to `command_api`. A release-script static gate prevents that direct pattern from being reintroduced.

## Validation performed in the ChatGPT build environment

PASS:
- TypeScript strict compilation (`tsc -p apps/shortcut-key-counter/ui/tsconfig.json`)
- `tauri.conf.json` JSON parse
- every `Cargo.toml` TOML parse
- frontend HTML parse
- required source/config/package files present

Not executable in this environment:
- `cargo fmt`, `cargo clippy`, `cargo test`, Windows MSVC build
- Win32 hooks, UAC, Named Pipe, system tray, registry and power lifecycle runtime tests
- Inno Setup build
- clean VM, 24h/72h soak tests

Reason: this Linux sandbox has no Rust/Cargo toolchain and cannot execute the Windows desktop APIs. Run `scripts/build-release.ps1` on Windows; it performs fmt, Clippy, all workspace tests and the release build before packaging.

## Required final release gate on Windows

Use `docs/WINDOWS_BUILD_AND_ACCEPTANCE.md` and `dev/release_checklist_v0.1.0.md`. An installer/ZIP should be called release-ready only after those Windows-only checks pass.


## Added lifecycle verification

`scripts/test-webview-lifecycle.ps1` verifies on a Windows release build that closing the main window destroys it, leaves the backend process alive, waits for descendant `msedgewebview2.exe` processes to reach zero, recreates the UI through the single-instance path, and repeats the destroy/release check. Physical notification-area double-click remains a manual Windows acceptance item because the sandbox has no Windows shell.

## Metadata

Help/installer metadata is set to author `KotoriChun` and GitHub repository `https://github.com/KotorinChunChun/ShortcutKeyCounter`.


## 2026-08-16 elevated/startup/state-sync fixes

- Elevated ON no longer calls `stop_capture()` on the normal-user hook. Local and elevated inputs converge on the same worker and duplicate guard.
- Elevated OFF no longer waits for the pipe reader `join()` in the Tauri command path. Pending pipe I/O is canceled and cleanup runs on a dedicated thread.
- Elevated helper connect has a 15-second timeout, preventing indefinite command hangs.
- Tray/WebView capture state uses the Tauri `capture-state-changed` event for immediate two-way display synchronization.
- Logon autostart command uses `-hide`; manual launch without parameters creates the UI.
- A Windows named Mutex prevents backend double start; a named activation Event asks the existing process to display Settings.
- App/tray icon is a single white 3D `C` key.

## 2026-08-16 名称・リアルタイムログ・テーマ更新

- 正式名称を `ShortcutKeyCounter` に統一。メインEXE、helper、Cargo package、Tauri、Installer、ZIP、LocalAppData、DB、ログ、CSV/JSON等も統一済み。
- リアルタイムログを750ms pollingから `realtime-log-changed` のイベント駆動へ変更。入力検知ログ追加ごとに即時差分更新。
- 設定画面へダーク/ライトテーマを追加。SQLite `settings.theme` に永続化しWebView再生成後も復元。
- TypeScript strict / JSON / TOML / HTML ID整合 / 旧名称検索 / 旧realtime timer検索を静的確認済み。

## v0.1.1 Native shortcut overlay

Implemented:
- Win32 layered/no-activate/click-through overlay window; no additional Tauri/WebView2 overlay
- active foreground-monitor work-area positioning and per-monitor DPI scaling
- 160ms enter + 840ms stable + 400ms fade, 1.4s TTL
- maximum 3-item animated stack
- bounded nonblocking Capture→Overlay queue
- overlay notification before the DB 1-second duplicate guard
- 50ms cross-source Local/Elevated overlay dedup
- SVG template rasterization/cache and shortcut bitmap LRU-style cache
- editable `overlay_key_labels.json`, `overlay-theme.json`, and default SVG files
- persisted `overlay_enabled` setting and Settings UI controls
- overlay failures isolated from Capture/SQLite
- release-script static regression gates for timing, stack, capture ordering, Elevated routing and click-through

Windows runtime acceptance is still required for visual timing, multi-monitor/DPI, focus/click-through and performance.
