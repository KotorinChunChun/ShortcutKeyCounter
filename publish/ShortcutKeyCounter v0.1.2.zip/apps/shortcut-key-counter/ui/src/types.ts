export interface CommandError { code: string; message: string }
export interface CaptureStatus { enabled: boolean; dropped_queue_items: number }
export type CaptureSource = 'local' | 'elevated' | 'local_fallback'
export type HealthLevel = 'ok' | 'degraded' | 'error'
export interface CaptureHealth { source: CaptureSource; level: HealthLevel; message: string | null }
export type Theme = 'dark' | 'light'
export interface SettingsSnapshot { auto_start: boolean; capture_elevated: boolean; theme: Theme; overlay_enabled: boolean }
export type OverlayPosition =
  | 'top-left' | 'top-center' | 'top-right'
  | 'middle-left' | 'center' | 'middle-right'
  | 'bottom-left' | 'bottom-center' | 'bottom-right'
export type OverlayPositionMode = 'fixed' | 'auto'
export type OverlayDisplayMode = 'desktop' | 'active-window'
export type OverlayMonitorMode = 'active-window' | 'fixed'
export type OverlayInAnimation = 'none' | 'fade' | 'slide-up' | 'slide-down' | 'slide-left' | 'slide-right' | 'pop'
export type OverlayOutAnimation = 'none' | 'fade' | 'slide-up' | 'slide-down' | 'slide-left' | 'slide-right' | 'shrink'
export type KeyAction = 'ignore' | 'continue_display' | 'display_break' | 'record_and_display_break'
export interface OverlayMonitor { id: string; label: string }
export interface OverlaySettings {
  enabled: boolean
  display_duration_ms: number
  display_mode: OverlayDisplayMode
  monitor_mode: OverlayMonitorMode
  fixed_monitor_id: string
  position_mode: OverlayPositionMode
  fixed_position: OverlayPosition
  max_rows: number
  background_color: string
  background_opacity: number
  enter_animation: OverlayInAnimation
  exit_animation: OverlayOutAnimation
  enter_ms: number
  exit_ms: number
  default_single_key_action: KeyAction
}
export interface KeyPolicy {
  version: number
  default_single_key: KeyAction
  default_shortcut: KeyAction
  overrides: Record<string, KeyAction>
}
export interface RankedShortcut { shortcut: string; count: number }
export interface ShortcutRankingRow extends RankedShortcut { application_count: number }
export interface RankedApplication { application: string; count: number }
export interface DailyPoint { date: string; count: number }
export interface DashboardSummary { total_count: number; unique_shortcuts: number; unique_applications: number; top_shortcut: RankedShortcut | null }
export interface ApplicationStats { application: string; count: number; unique_shortcuts: number; most_used_shortcut: string | null }
export interface ShortcutDetail { shortcut: string; total_count: number; applications: RankedApplication[]; daily: DailyPoint[] }
export interface ExcludedApp { id: number; executable_name: string; source: 'default' | 'user' | string; enabled: boolean }
export interface ExportResult { path: string; rows: number }
export interface BackupResult { path: string }
export interface ClearResult { events_deleted: number; daily_deleted: number }
export interface DataBounds { first_date: string | null; last_date: string | null }
export interface AppPaths { data_directory: string; database_path: string; logs_directory: string }
export type RangeKey = 'today' | '7' | '30' | 'all'
export interface DateRange { start: string; end: string }

export interface KeyMappingEntry { virtual_key: number; name: string; enabled: boolean }
export interface MouseKeyMapping { left_click: boolean; right_click: boolean; middle_click: boolean; wheel_up: boolean; wheel_down: boolean }
export interface KeyMapping { version: number; keyboard: KeyMappingEntry[]; mouse: MouseKeyMapping }
export interface KeyMappingExportResult { path: string }
export interface RealtimeLogEntry { sequence: number; occurred_at: string; shortcut: string; application: string; outcome: string }
export interface AppInfo { name: string; version: string; author: string; github_url: string }
