import { api } from './api.js'
import type {
  ApplicationStats, CaptureHealth, CaptureStatus, DailyPoint, DateRange, ExcludedApp,
  RangeKey, SettingsSnapshot, ShortcutRankingRow, KeyMapping, RealtimeLogEntry, AppInfo, Theme,
  OverlaySettings, OverlayPosition, OverlayPositionMode, OverlayDisplayMode, OverlayMonitorMode,
  OverlayMonitor, KeyAction, KeyPolicy
} from './types.js'

const titles: Record<string, string> = {
  dashboard: 'ダッシュボード', 'daily-ranking': '日刊ランキング', ranking: '累計キー別ランキング',
  applications: 'アプリ別ランキング', matrix: 'キー × アプリ見取り図',
  'shortcut-detail': 'ショートカット詳細', 'realtime-log': 'リアルタイムログ', 'key-mapping': 'キーマッピング',
  excluded: '除外アプリ', data: 'データ管理', settings: '設定', help: 'ヘルプ'
}
const rankingPages = ['daily-ranking', 'ranking', 'applications', 'realtime-log', 'matrix']
const rangeState: Record<string, RangeKey> = {
  dashboard: 'today', ranking: 'all', applications: 'all', matrix: '7', 'shortcut-detail': 'today'
}
let activePage = 'dashboard'
let polling = false
let toastTimer = 0
let cachedBounds: Awaited<ReturnType<typeof api.dataBounds>> | null = null
let currentKeyMapping: KeyMapping | null = null
let currentKeyPolicy: KeyPolicy | null = null
let realtimeSequence = 0
let realtimeEntries: RealtimeLogEntry[] = []
let appInfo: AppInfo | null = null
let elevatedBusy = false
let realtimeLoading = false
let realtimeReloadPending = false
let currentOverlaySettings: OverlaySettings | null = null
let currentOverlayMonitors: OverlayMonitor[] = []

function applyTheme(theme: Theme): void {
  document.documentElement.dataset.theme = theme
  window.localStorage.setItem('shortcut-key-counter-theme', theme)
}

const cachedTheme = window.localStorage.getItem('shortcut-key-counter-theme')
if (cachedTheme === 'dark' || cachedTheme === 'light') applyTheme(cachedTheme)

function el<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id)
  if (!node) throw new Error(`Missing element: ${id}`)
  return node as T
}
function escapeHtml(value: unknown): string {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char] ?? char))
}
function showToast(message: string, action?: { label: string; run: () => Promise<void> }): void {
  const toast = el<HTMLDivElement>('toast')
  el<HTMLSpanElement>('toastText').textContent = message
  const actionButton = el<HTMLButtonElement>('toastAction')
  actionButton.style.display = action ? '' : 'none'
  actionButton.textContent = action?.label ?? 'フォルダーを開く'
  actionButton.onclick = action ? () => void action.run().catch(error => showToast(errorMessage(error))) : null
  toast.classList.toggle('has-action', Boolean(action))
  toast.classList.add('show')
  window.clearTimeout(toastTimer)
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), action ? 8000 : 3200)
}
function errorMessage(error: unknown): string {
  if (typeof error === 'object' && error !== null && 'message' in error) {
    return String((error as { message: unknown }).message)
  }
  return String(error)
}
function formatNumber(value: number): string { return new Intl.NumberFormat('ja-JP').format(value) }
function todayText(date = new Date()): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}
function addDays(dateText: string, offset: number): string {
  const [y, m, d] = dateText.split('-').map(Number)
  if (!y || !m || !d) return dateText
  const date = new Date(y, m - 1, d)
  date.setDate(date.getDate() + offset)
  return todayText(date)
}
async function resolveRange(key: RangeKey): Promise<DateRange> {
  const end = todayText()
  if (key === 'today') return { start: end, end }
  if (key === '7') return { start: addDays(end, -6), end }
  if (key === '30') return { start: addDays(end, -29), end }
  cachedBounds ??= await api.dataBounds()
  return {
    start: cachedBounds.first_date ?? end,
    end: cachedBounds.last_date ?? end,
  }
}
function rangeLabel(range: DateRange): string {
  return range.start === range.end ? range.start : `${range.start} ～ ${range.end}`
}
function kbd(shortcut: string): string {
  return `<span class="kbd">${shortcut.split('+').map(key => `<span class="key">${escapeHtml(key)}</span>`).join('+')}</span>`
}
function emptyRow(columns: number, message = 'データがありません。'): string {
  return `<tr><td colspan="${columns}" class="empty">${escapeHtml(message)}</td></tr>`
}
function renderBars(container: HTMLElement, rows: Array<{ name: string; count: number }>): void {
  if (!rows.length) {
    container.innerHTML = '<div class="empty">データがありません。</div>'
    return
  }
  const max = Math.max(...rows.map(row => row.count), 1)
  container.innerHTML = rows.map(row => `<div class="app-row"><span class="exe">${escapeHtml(row.name)}</span><div class="bar-track"><div class="bar" style="width:${Math.max(2, row.count / max * 100)}%"></div></div><b>${formatNumber(row.count)}</b></div>`).join('')
}
function renderChart(container: HTMLElement, points: DailyPoint[]): void {
  if (!points.length) {
    container.innerHTML = '<div class="empty" style="width:100%">データがありません。</div>'
    return
  }
  const max = Math.max(...points.map(point => point.count), 1)
  container.innerHTML = points.map(point => {
    const [, month, day] = point.date.split('-')
    const label = month && day ? `${Number(month)}/${Number(day)}` : point.date
    const height = point.count === 0 ? 1 : Math.max(3, point.count / max * 100)
    return `<div class="day" title="${escapeHtml(point.date)}: ${formatNumber(point.count)}"><span style="height:${height}%"></span><label>${escapeHtml(label)}</label></div>`
  }).join('')
}

async function refreshCaptureStatus(): Promise<void> {
  try {
    const [status, health] = await Promise.all([api.captureStatus(), api.captureHealth()])
    renderCaptureStatus(status, health)
  } catch (error) {
    const chip = el<HTMLDivElement>('statusChip')
    chip.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#ef6b73"></span><span>状態不明</span>'
    el<HTMLDivElement>('healthLine').textContent = errorMessage(error)
  }
}
function renderCaptureStatus(status: CaptureStatus, health: CaptureHealth): void {
  const chip = el<HTMLDivElement>('statusChip')
  const button = el<HTMLButtonElement>('captureBtn')
  const setting = el<HTMLSpanElement>('captureSettingStatus')
  chip.innerHTML = status.enabled
    ? '<span class="dot"></span><span>計測中</span>'
    : '<span style="width:7px;height:7px;border-radius:50%;background:#ef6b73"></span><span>停止中</span>'
  chip.classList.toggle('stopped', !status.enabled)
  button.textContent = status.enabled ? '計測を停止' : '計測を再開'
  button.classList.toggle('off', !status.enabled)
  setting.textContent = status.enabled ? 'ON' : 'OFF'
  setting.className = status.enabled ? 'status-ok' : 'status-off'
  const source = health.source === 'elevated' ? '通常権限 + 管理者権限Capture' : health.source === 'local_fallback' ? '通常権限（helper切断）' : '通常権限Capture'
  el<HTMLDivElement>('healthLine').textContent = `${source}${status.dropped_queue_items ? ` / queue drop ${status.dropped_queue_items}` : ''}`
}

async function loadDashboard(): Promise<void> {
  const range = await resolveRange(rangeState.dashboard ?? 'today')
  const [summary, trend, apps, shortcuts] = await Promise.all([
    api.dashboard(range.start, range.end),
    api.dailyTrend(range.start, range.end),
    api.applicationRanking(range.start, range.end, 4),
    api.shortcutRankingExtended(range.start, range.end, null, 5),
  ])
  let topApp = ''
  if (summary.top_shortcut) {
    const detail = await api.shortcutDetail(summary.top_shortcut.shortcut, range.start, range.end)
    topApp = detail.applications[0]?.application ?? ''
  }
  el<HTMLDivElement>('dashboardCards').innerHTML = `
    <div class="card"><div class="card-label">ショートカット利用回数</div><div class="card-value">${formatNumber(summary.total_count)}</div><div class="card-note">${escapeHtml(rangeLabel(range))}</div></div>
    <div class="card"><div class="card-label">ユニークショートカット</div><div class="card-value">${formatNumber(summary.unique_shortcuts)}</div><div class="card-note">選択期間の種類数</div></div>
    <div class="card"><div class="card-label">利用アプリ</div><div class="card-value">${formatNumber(summary.unique_applications)}</div><div class="card-note">記録対象アプリ数</div></div>
    <div class="card"><div class="card-label">最多ショートカット</div><div class="card-value small">${summary.top_shortcut ? kbd(summary.top_shortcut.shortcut) : '—'}</div><div class="card-note">${summary.top_shortcut ? `${formatNumber(summary.top_shortcut.count)}回${topApp ? ` / ${escapeHtml(topApp)}` : ''}` : 'データなし'}</div></div>`
  el<HTMLSpanElement>('dashboardTrendLabel').textContent = rangeLabel(range)
  renderChart(el('dashboardTrend'), trend)
  renderBars(el('dashboardApps'), apps.map(row => ({ name: row.application, count: row.count })))
  renderShortcutRanking(el('dashboardRanking'), shortcuts)
}
function renderShortcutRanking(container: HTMLElement, rows: ShortcutRankingRow[]): void {
  if (!rows.length) { container.innerHTML = emptyRow(5); return }
  const max = Math.max(...rows.map(row => row.count), 1)
  container.innerHTML = rows.map((row, index) => `<tr class="clickable" data-shortcut="${escapeHtml(row.shortcut)}"><td>${index + 1}</td><td>${kbd(row.shortcut)}</td><td><b>${formatNumber(row.count)}</b></td><td>${row.application_count}</td><td><div class="bar-track"><div class="bar" style="width:${row.count / max * 100}%"></div></div></td></tr>`).join('')
  container.querySelectorAll<HTMLTableRowElement>('tr[data-shortcut]').forEach(row => row.addEventListener('click', () => {
    const shortcut = row.dataset.shortcut
    if (shortcut) void openShortcutDetail(shortcut)
  }))
}


function treeRatio(value: number, total: number): string {
  return total > 0 ? `${(value / total * 100).toFixed(1)}%` : '0.0%'
}

function removeTreeChildren(body: HTMLElement, parentIndex: string): void {
  body.querySelectorAll(`[data-tree-child="${parentIndex}"]`).forEach(node => node.remove())
}

function renderKeyTree(
  body: HTMLTableSectionElement,
  rows: ShortcutRankingRow[],
  range: DateRange,
  showApplicationCount: boolean,
  applicationFilter: string | null = null,
): void {
  const columns = showApplicationCount ? 5 : 4
  if (!rows.length) { body.innerHTML = emptyRow(columns); return }
  const total = rows.reduce((sum, row) => sum + row.count, 0)
  body.innerHTML = rows.map((row, index) => `<tr class="tree-parent clickable" data-tree-index="key-${index}" data-shortcut="${escapeHtml(row.shortcut)}"><td>${index + 1}</td><td><span class="tree-arrow">▸</span>${kbd(row.shortcut)}</td><td><b>${formatNumber(row.count)}</b></td>${showApplicationCount ? `<td>${row.application_count}</td>` : ''}<td>${treeRatio(row.count, total)}</td></tr>`).join('')
  body.querySelectorAll<HTMLTableRowElement>('tr[data-shortcut]').forEach(parent => parent.addEventListener('click', async () => {
    const shortcut = parent.dataset.shortcut
    const parentIndex = parent.dataset.treeIndex
    if (!shortcut || !parentIndex) return
    const arrow = parent.querySelector<HTMLElement>('.tree-arrow')
    if (parent.classList.toggle('expanded') === false) {
      removeTreeChildren(body, parentIndex)
      if (arrow) arrow.textContent = '▸'
      return
    }
    if (arrow) arrow.textContent = '▾'
    try {
      const detail = await api.shortcutDetail(shortcut, range.start, range.end)
      const applications = applicationFilter ? detail.applications.filter(row => row.application === applicationFilter) : detail.applications
      const childHtml = applications.length
        ? applications.map(app => `<tr class="tree-child" data-tree-child="${parentIndex}"><td></td><td><span class="tree-branch">└</span><span class="exe">${escapeHtml(app.application)}</span></td><td>${formatNumber(app.count)}</td>${showApplicationCount ? '<td></td>' : ''}<td>${treeRatio(app.count, detail.total_count)}</td></tr>`).join('')
        : `<tr class="tree-child" data-tree-child="${parentIndex}"><td></td><td colspan="${columns - 1}" class="muted">内訳がありません。</td></tr>`
      parent.insertAdjacentHTML('afterend', childHtml)
    } catch (error) {
      parent.classList.remove('expanded')
      if (arrow) arrow.textContent = '▸'
      showToast(errorMessage(error))
    }
  }))
}

function renderApplicationTree(
  body: HTMLTableSectionElement,
  rows: ApplicationStats[],
  range: DateRange,
  showUniqueShortcuts: boolean,
): void {
  const columns = showUniqueShortcuts ? 5 : 4
  if (!rows.length) { body.innerHTML = emptyRow(columns); return }
  const total = rows.reduce((sum, row) => sum + row.count, 0)
  body.innerHTML = rows.map((row, index) => `<tr class="tree-parent clickable" data-tree-index="app-${index}" data-application="${escapeHtml(row.application)}"><td>${index + 1}</td><td><span class="tree-arrow">▸</span><span class="exe">${escapeHtml(row.application)}</span></td><td><b>${formatNumber(row.count)}</b></td>${showUniqueShortcuts ? `<td>${row.unique_shortcuts}</td>` : ''}<td>${treeRatio(row.count, total)}</td></tr>`).join('')
  body.querySelectorAll<HTMLTableRowElement>('tr[data-application]').forEach(parent => parent.addEventListener('click', async () => {
    const application = parent.dataset.application
    const parentIndex = parent.dataset.treeIndex
    if (!application || !parentIndex) return
    const arrow = parent.querySelector<HTMLElement>('.tree-arrow')
    if (parent.classList.toggle('expanded') === false) {
      removeTreeChildren(body, parentIndex)
      if (arrow) arrow.textContent = '▸'
      return
    }
    if (arrow) arrow.textContent = '▾'
    try {
      const shortcuts = await api.shortcutRankingExtended(range.start, range.end, application, 100)
      const childHtml = shortcuts.length
        ? shortcuts.map(row => `<tr class="tree-child" data-tree-child="${parentIndex}"><td></td><td><span class="tree-branch">└</span>${kbd(row.shortcut)}</td><td>${formatNumber(row.count)}</td>${showUniqueShortcuts ? '<td></td>' : ''}<td>${treeRatio(row.count, rows.find(item => item.application === application)?.count ?? 0)}</td></tr>`).join('')
        : `<tr class="tree-child" data-tree-child="${parentIndex}"><td></td><td colspan="${columns - 1}" class="muted">内訳がありません。</td></tr>`
      parent.insertAdjacentHTML('afterend', childHtml)
    } catch (error) {
      parent.classList.remove('expanded')
      if (arrow) arrow.textContent = '▸'
      showToast(errorMessage(error))
    }
  }))
}

async function loadDailyRanking(): Promise<void> {
  const dateInput = el<HTMLInputElement>('dailyRankingDate')
  if (!dateInput.value) dateInput.value = todayText()
  const date = dateInput.value || todayText()
  const range = { start: date, end: date }
  const [keys, apps] = await Promise.all([
    api.shortcutRankingExtended(date, date, null, 100),
    api.applicationStatistics(date, date),
  ])
  renderKeyTree(el<HTMLTableSectionElement>('dailyKeyRankingBody'), keys, range, false)
  renderApplicationTree(el<HTMLTableSectionElement>('dailyAppRankingBody'), apps, range, false)
}

async function loadRanking(): Promise<void> {
  const range = await resolveRange(rangeState.ranking ?? 'all')
  const filter = el<HTMLSelectElement>('rankingAppFilter')
  const selected = filter.value
  const [rows, apps] = await Promise.all([
    api.shortcutRankingExtended(range.start, range.end, selected || null, 200),
    api.applicationStatistics(range.start, range.end),
  ])
  const appNames = apps.map(app => app.application)
  filter.innerHTML = '<option value="">すべてのアプリ</option>' + appNames.map(name => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join('')
  if (appNames.includes(selected)) filter.value = selected
  renderKeyTree(el<HTMLTableSectionElement>('rankingBody'), rows, range, true, selected || null)
}

async function loadApplications(): Promise<void> {
  const range = await resolveRange(rangeState.applications ?? 'all')
  const rows = await api.applicationStatistics(range.start, range.end)
  const total = rows.reduce((sum, row) => sum + row.count, 0)
  const top = rows.slice(0, 3)
  const other = rows.slice(3).reduce((sum, row) => sum + row.count, 0)
  const cards = [...top.map(row => ({ name: row.application, count: row.count })), ...(other ? [{ name: 'その他', count: other }] : [])]
  el<HTMLDivElement>('applicationCards').innerHTML = cards.length ? cards.map(row => `<div class="card"><div class="card-label exe">${escapeHtml(row.name)}</div><div class="card-value">${formatNumber(row.count)}</div><div class="card-note">${total ? (row.count / total * 100).toFixed(1) : '0.0'}%</div></div>`).join('') : '<div class="card"><div class="card-label">データ</div><div class="card-value">0</div><div class="card-note">まだ記録がありません</div></div>'
  renderApplicationTree(el<HTMLTableSectionElement>('applicationBody'), rows, range, true)
}

async function loadShortcutDetail(preferred?: string): Promise<void> {
  const range = await resolveRange(rangeState['shortcut-detail'] ?? 'today')
  const select = el<HTMLSelectElement>('shortcutSelect')
  const before = preferred ?? select.value
  const catalog = await api.listShortcuts(range.start, range.end)
  select.innerHTML = catalog.length ? catalog.map(row => `<option value="${escapeHtml(row.shortcut)}">${escapeHtml(row.shortcut)} (${formatNumber(row.count)})</option>`).join('') : '<option value="">データなし</option>'
  const values = catalog.map(row => row.shortcut)
  if (before && values.includes(before)) select.value = before
  const shortcut = select.value
  if (!shortcut) {
    el('selectedShortcut').textContent = '—'; el('detailTotal').textContent = '0'; el('detailAppCount').textContent = '0'
    renderBars(el('detailApps'), []); renderChart(el('detailTrend'), [])
    return
  }
  const detail = await api.shortcutDetail(shortcut, range.start, range.end)
  el('selectedShortcut').innerHTML = kbd(detail.shortcut)
  el('detailTotal').textContent = formatNumber(detail.total_count)
  el('detailAppCount').textContent = formatNumber(detail.applications.length)
  renderBars(el('detailApps'), detail.applications.map(row => ({ name: row.application, count: row.count })))
  renderChart(el('detailTrend'), detail.daily)
}
async function openShortcutDetail(shortcut: string): Promise<void> {
  goPage('shortcut-detail')
  await loadShortcutDetail(shortcut)
}

function renderExcluded(rows: ExcludedApp[]): void {
  const body = el<HTMLTableSectionElement>('excludeBody')
  if (!rows.length) { body.innerHTML = emptyRow(4); return }
  body.innerHTML = rows.map(row => `<tr><td class="exe">${escapeHtml(row.executable_name)}</td><td><span class="pill">${escapeHtml(row.source)}</span></td><td><span class="${row.enabled ? 'status-ok' : 'status-off'}">${row.enabled ? '除外中' : '解除済み'}</span></td><td>${row.source === 'user' ? `<button class="btn ghost" data-remove="${escapeHtml(row.executable_name)}">削除</button>` : `<button class="btn ghost" data-toggle="${escapeHtml(row.executable_name)}" data-enabled="${row.enabled}">${row.enabled ? '解除' : '再度除外'}</button>`}</td></tr>`).join('')
  body.querySelectorAll<HTMLButtonElement>('button[data-remove]').forEach(button => button.addEventListener('click', async () => {
    const name = button.dataset.remove
    if (!name) return
    try { renderExcluded(await api.removeExcludedApp(name)); showToast(`${name} を除外リストから削除しました。`) } catch (error) { showToast(errorMessage(error)) }
  }))
  body.querySelectorAll<HTMLButtonElement>('button[data-toggle]').forEach(button => button.addEventListener('click', async () => {
    const name = button.dataset.toggle
    const enabled = button.dataset.enabled === 'true'
    if (!name) return
    if (enabled && !window.confirm('デフォルト除外を解除しますか？\n機密入力を扱う可能性があるアプリです。')) return
    try { renderExcluded(await api.setExcludedEnabled(name, !enabled)); showToast(`${name} の除外設定を更新しました。`) } catch (error) { showToast(errorMessage(error)) }
  }))
}
async function loadExcluded(): Promise<void> { renderExcluded(await api.excludedApps()) }

function setSwitch(node: HTMLElement, enabled: boolean): void { node.classList.toggle('on', enabled) }
function renderOverlaySettings(settings: OverlaySettings): void {
  currentOverlaySettings = structuredClone(settings)
  setSwitch(el('overlaySwitch'), settings.enabled)
  el<HTMLInputElement>('overlayDuration').value = (settings.display_duration_ms / 1000).toFixed(1)
  el<HTMLInputElement>('overlayMaxRows').value = String(settings.max_rows)
  el<HTMLInputElement>('overlayBackgroundColor').value = settings.background_color
  el<HTMLInputElement>('overlayBackgroundColorPicker').value = settings.background_color
  el<HTMLInputElement>('overlayBackgroundOpacity').value = String(Math.round(settings.background_opacity * 100))
  el('overlayOpacityValue').textContent = `${Math.round(settings.background_opacity * 100)}%`
  el<HTMLSelectElement>('overlayDisplayMode').value = settings.display_mode
  el<HTMLSelectElement>('overlayMonitorMode').value = settings.monitor_mode
  renderOverlayMonitorOptions(settings)
  el<HTMLSelectElement>('overlayEnterAnimation').value = settings.enter_animation
  el<HTMLSelectElement>('overlayExitAnimation').value = settings.exit_animation
  el<HTMLInputElement>('overlayEnterMs').value = String(settings.enter_ms)
  el<HTMLInputElement>('overlayExitMs').value = String(settings.exit_ms)

  document.querySelectorAll<HTMLButtonElement>('#overlayPositionMode button[data-mode]').forEach(button => {
    button.classList.toggle('active', button.dataset.mode === settings.position_mode)
  })
  const grid = el<HTMLDivElement>('overlayPositionGrid')
  grid.classList.toggle('is-auto', settings.position_mode === 'auto')
  grid.querySelectorAll<HTMLButtonElement>('button[data-position]').forEach(button => {
    button.classList.toggle('active', button.dataset.position === settings.fixed_position)
    button.disabled = settings.position_mode === 'auto'
    button.setAttribute('aria-pressed', String(button.dataset.position === settings.fixed_position))
  })
}

function renderOverlayMonitorOptions(settings: OverlaySettings): void {
  const select = el<HTMLSelectElement>('overlayMonitorSelect')
  const current = settings.fixed_monitor_id
  select.innerHTML = currentOverlayMonitors.length
    ? currentOverlayMonitors.map(monitor => `<option value="${escapeHtml(monitor.id)}">${escapeHtml(monitor.label)}</option>`).join('')
    : '<option value="">モニター情報を取得できません</option>'
  if (current && currentOverlayMonitors.some(monitor => monitor.id === current)) select.value = current
  else if (currentOverlayMonitors[0]) select.value = currentOverlayMonitors[0].id
  select.disabled = settings.monitor_mode !== 'fixed' || settings.display_mode === 'active-window'
}

function overlaySettingsFromUi(): OverlaySettings | null {
  if (!currentOverlaySettings) return null
  const mode = document.querySelector<HTMLButtonElement>('#overlayPositionMode button.active')?.dataset.mode as OverlayPositionMode | undefined
  const position = document.querySelector<HTMLButtonElement>('#overlayPositionGrid button.active')?.dataset.position as OverlayPosition | undefined
  const durationSeconds = Number(el<HTMLInputElement>('overlayDuration').value)
  const maxRows = Number(el<HTMLInputElement>('overlayMaxRows').value)
  const opacity = Number(el<HTMLInputElement>('overlayBackgroundOpacity').value) / 100
  const enterMs = Number(el<HTMLInputElement>('overlayEnterMs').value)
  const exitMs = Number(el<HTMLInputElement>('overlayExitMs').value)
  const color = el<HTMLInputElement>('overlayBackgroundColor').value.trim()
  const displayMode = el<HTMLSelectElement>('overlayDisplayMode').value as OverlayDisplayMode
  const monitorMode = el<HTMLSelectElement>('overlayMonitorMode').value as OverlayMonitorMode
  const fixedMonitorId = el<HTMLSelectElement>('overlayMonitorSelect').value
  if (!mode || !position || !displayMode || !monitorMode || !Number.isFinite(durationSeconds) || !Number.isFinite(maxRows) || !Number.isFinite(opacity) || !Number.isFinite(enterMs) || !Number.isFinite(exitMs)) return null
  return {
    ...currentOverlaySettings,
    display_duration_ms: Math.round(durationSeconds * 1000),
    display_mode: displayMode,
    monitor_mode: monitorMode,
    fixed_monitor_id: fixedMonitorId,
    position_mode: mode,
    fixed_position: position,
    max_rows: Math.round(maxRows),
    background_color: color,
    background_opacity: opacity,
    enter_animation: el<HTMLSelectElement>('overlayEnterAnimation').value as OverlaySettings['enter_animation'],
    exit_animation: el<HTMLSelectElement>('overlayExitAnimation').value as OverlaySettings['exit_animation'],
    enter_ms: Math.round(enterMs),
    exit_ms: Math.round(exitMs),
  }
}

function validateOverlaySettings(settings: OverlaySettings): string | null {
  if (settings.display_duration_ms < 100 || settings.display_duration_ms > 10000) return '表示時間は0.1〜10秒で指定してください。'
  if (settings.max_rows < 1 || settings.max_rows > 10) return '最大表示行数は1〜10行で指定してください。'
  if (!/^#[0-9a-fA-F]{6}$/.test(settings.background_color)) return '背景色は #RRGGBB 形式で指定してください。'
  if (settings.background_opacity < 0 || settings.background_opacity > 1) return '背景透明度は0〜100%で指定してください。'
  if (settings.enter_ms < 0 || settings.enter_ms > 2000 || settings.exit_ms < 0 || settings.exit_ms > 2000) return 'アニメーション時間は0〜2000msで指定してください。'
  return null
}

async function saveOverlaySettingsFromUi(showMessage = true): Promise<void> {
  const settings = overlaySettingsFromUi()
  if (!settings) return
  const validationError = validateOverlaySettings(settings)
  if (validationError) { showToast(validationError); return }
  currentOverlaySettings = await api.setOverlaySettings(settings)
  renderOverlaySettings(currentOverlaySettings)
  if (showMessage) showToast('オーバーレイ設定を保存しました。')
}

async function renderSettings(settings?: SettingsSnapshot): Promise<void> {
  const [resolvedSettings, status, health, paths, overlaySettings, monitors] = await Promise.all([
    settings ? Promise.resolve(settings) : api.settings(), api.captureStatus(), api.captureHealth(), api.appPaths(), api.overlaySettings(), api.overlayMonitors()
  ])
  applyTheme(resolvedSettings.theme)
  document.querySelectorAll<HTMLButtonElement>('#themeControl button[data-theme]').forEach(button => {
    button.classList.toggle('active', button.dataset.theme === resolvedSettings.theme)
  })
  setSwitch(el('autoStartSwitch'), resolvedSettings.auto_start)
  setSwitch(el('elevatedSwitch'), resolvedSettings.capture_elevated)
  setSwitch(el('overlaySwitch'), resolvedSettings.overlay_enabled)
  currentOverlayMonitors = monitors
  renderOverlaySettings(overlaySettings)
  el('dbPath').textContent = paths.database_path
  const sourceText = health.source === 'elevated' ? '通常権限Hook + ShortcutKeyCapture.exe（管理者権限）' : health.source === 'local_fallback' ? '通常権限Capture（helper切断後も継続）' : '通常権限Capture'
  el('captureHealthText').textContent = health.message ? `${sourceText} — ${health.message}` : sourceText
  const level = el('captureHealthLevel')
  level.textContent = health.level === 'ok' ? '正常' : health.level === 'degraded' ? '縮退' : 'エラー'
  level.className = health.level === 'ok' ? 'status-ok' : 'status-off'
  renderCaptureStatus(status, health)
}


function outcomeLabel(outcome: string): string {
  return ({ recorded: '記録', display_only: '表示のみ', ignored: 'ポリシー無視', duplicate: '1秒重複', excluded: '除外アプリ', mapping_disabled: 'マッピングOFF', unsupported: '未対応', invalid_application: 'アプリ不明', ineligible: '対象外' } as Record<string, string>)[outcome] ?? outcome
}

function renderRealtimeLog(): void {
  const body = el<HTMLTableSectionElement>('realtimeLogBody')
  if (!realtimeEntries.length) { body.innerHTML = emptyRow(4, 'ショートカット入力を待っています。'); return }
  body.innerHTML = realtimeEntries.slice().reverse().map(entry => `<tr><td class="exe">${escapeHtml(entry.occurred_at.split(' ')[1] ?? entry.occurred_at)}</td><td>${kbd(entry.shortcut)}</td><td class="exe">${escapeHtml(entry.application)}</td><td><span class="pill outcome-${escapeHtml(entry.outcome)}">${escapeHtml(outcomeLabel(entry.outcome))}</span></td></tr>`).join('')
}

async function loadRealtimeLog(): Promise<void> {
  if (realtimeLoading) {
    realtimeReloadPending = true
    return
  }
  realtimeLoading = true
  try {
    do {
      realtimeReloadPending = false
      const incoming = await api.realtimeLogs(realtimeSequence, 500)
      if (incoming.length) {
        realtimeSequence = incoming[incoming.length - 1]?.sequence ?? realtimeSequence
        realtimeEntries.push(...incoming)
        if (realtimeEntries.length > 500) realtimeEntries = realtimeEntries.slice(-500)
      }
      renderRealtimeLog()
    } while (realtimeReloadPending)
  } finally {
    realtimeLoading = false
  }
}


async function loadMatrix(): Promise<void> {
  const range = await resolveRange(rangeState.matrix ?? '7')
  const [keys, apps] = await Promise.all([
    api.shortcutRankingExtended(range.start, range.end, null, 8),
    api.applicationRanking(range.start, range.end, 6),
  ])
  el('matrixRangeLabel').textContent = rangeLabel(range)
  const head = el<HTMLTableSectionElement>('matrixHead')
  const body = el<HTMLTableSectionElement>('matrixBody')
  if (!keys.length || !apps.length) {
    head.innerHTML = '<tr><th>Shortcut</th></tr>'
    body.innerHTML = emptyRow(1)
    return
  }
  const perApp = await Promise.all(apps.map(async app => ({
    application: app.application,
    rows: await api.shortcutRankingExtended(range.start, range.end, app.application, 200),
  })))
  const maps = new Map(perApp.map(group => [group.application, new Map(group.rows.map(row => [row.shortcut, row.count]))]))
  let maxCell = 1
  for (const key of keys) for (const app of apps) maxCell = Math.max(maxCell, maps.get(app.application)?.get(key.shortcut) ?? 0)
  head.innerHTML = `<tr><th>Shortcut</th>${apps.map(app => `<th class="exe">${escapeHtml(app.application)}</th>`).join('')}<th>合計</th></tr>`
  body.innerHTML = keys.map(key => `<tr><td>${kbd(key.shortcut)}</td>${apps.map(app => {
    const count = maps.get(app.application)?.get(key.shortcut) ?? 0
    const heat = count / maxCell
    return `<td class="heat-cell" style="--heat:${heat.toFixed(3)}" title="${escapeHtml(key.shortcut)} / ${escapeHtml(app.application)}: ${formatNumber(count)}">${formatNumber(count)}</td>`
  }).join('')}<td><b>${formatNumber(key.count)}</b></td></tr>`).join('')
}

type ModifierPattern = { id: string; label: string; parts: string[] }
const modifierPatterns: ModifierPattern[] = [
  { id: 'none', label: 'なし', parts: [] },
  { id: 'ctrl', label: 'Ctrl', parts: ['Ctrl'] },
  { id: 'alt', label: 'Alt', parts: ['Alt'] },
  { id: 'win', label: 'Win', parts: ['Win'] },
  { id: 'shift', label: 'Shift', parts: ['Shift'] },
  { id: 'ctrl-alt', label: 'Ctrl+Alt', parts: ['Ctrl', 'Alt'] },
  { id: 'ctrl-win', label: 'Ctrl+Win', parts: ['Ctrl', 'Win'] },
  { id: 'ctrl-shift', label: 'Ctrl+Shift', parts: ['Ctrl', 'Shift'] },
  { id: 'alt-win', label: 'Alt+Win', parts: ['Alt', 'Win'] },
  { id: 'alt-shift', label: 'Alt+Shift', parts: ['Alt', 'Shift'] },
  { id: 'win-shift', label: 'Win+Shift', parts: ['Win', 'Shift'] },
  { id: 'ctrl-alt-win', label: 'Ctrl+Alt+Win', parts: ['Ctrl', 'Alt', 'Win'] },
  { id: 'ctrl-alt-shift', label: 'Ctrl+Alt+Shift', parts: ['Ctrl', 'Alt', 'Shift'] },
  { id: 'ctrl-win-shift', label: 'Ctrl+Win+Shift', parts: ['Ctrl', 'Win', 'Shift'] },
  { id: 'alt-win-shift', label: 'Alt+Win+Shift', parts: ['Alt', 'Win', 'Shift'] },
  { id: 'ctrl-alt-win-shift', label: 'Ctrl+Alt+Win+Shift', parts: ['Ctrl', 'Alt', 'Win', 'Shift'] },
]
const keyActionOptions: Array<[KeyAction, string]> = [
  ['ignore', 'なし'],
  ['continue_display', '続けて表示'],
  ['display_break', '表示して改行'],
  ['record_and_display_break', '記録と表示改行'],
]

type PolicyRow = { key: string; label: string }
function policyRows(mapping: KeyMapping): PolicyRow[] {
  return [
    ...mapping.keyboard.map(entry => ({ key: entry.name, label: entry.name })),
    { key: 'MouseLeft', label: 'Left Click' },
    { key: 'MouseMiddle', label: 'Middle Click' },
    { key: 'MouseRight', label: 'Right Click' },
    { key: 'WheelUp', label: 'Wheel ↑' },
    { key: 'WheelDown', label: 'Wheel ↓' },
  ]
}

function policyIdentity(pattern: ModifierPattern, key: string): string {
  return pattern.parts.length ? `${pattern.parts.join('+')}+${key}` : key
}

function defaultPolicyAction(policy: KeyPolicy, pattern: ModifierPattern): KeyAction {
  return pattern.parts.length ? policy.default_shortcut : policy.default_single_key
}

function renderKeyMapping(mapping: KeyMapping, policy: KeyPolicy): void {
  currentKeyMapping = structuredClone(mapping)
  currentKeyPolicy = structuredClone(policy)
  const head = el<HTMLTableSectionElement>('keyPolicyMatrixHead')
  const body = el<HTMLTableSectionElement>('keyPolicyMatrixBody')
  head.innerHTML = `<tr><th class="key-policy-key-head">キー</th>${modifierPatterns.map(pattern => `<th class="key-policy-pattern">${escapeHtml(pattern.label)}</th>`).join('')}</tr>`
  const rows = policyRows(mapping)
  const options = (selected: KeyAction): string => keyActionOptions.map(([value, label]) => `<option value="${value}" ${selected === value ? 'selected' : ''}>${label}</option>`).join('')
  body.innerHTML = rows.map(row => `<tr><th class="key-policy-key">${escapeHtml(row.label)}</th>${modifierPatterns.map(pattern => {
    const identity = policyIdentity(pattern, row.key)
    const fallback = defaultPolicyAction(policy, pattern)
    const selected = policy.overrides[identity] ?? fallback
    return `<td><select class="select key-policy-select" data-policy-identity="${escapeHtml(identity)}" data-policy-default="${fallback}">${options(selected)}</select></td>`
  }).join('')}</tr>`).join('')
  updateMappingSummary()
}

function mappingFromUi(): KeyMapping {
  return structuredClone(currentKeyMapping ?? { version: 1, keyboard: [], mouse: { left_click: true, right_click: true, middle_click: true, wheel_up: true, wheel_down: true } })
}

function policyFromUi(): KeyPolicy {
  const policy = structuredClone(currentKeyPolicy ?? {
    version: 2,
    default_single_key: 'continue_display' as KeyAction,
    default_shortcut: 'record_and_display_break' as KeyAction,
    overrides: {},
  }) as KeyPolicy
  document.querySelectorAll<HTMLSelectElement>('#keyPolicyMatrixBody select[data-policy-identity]').forEach(select => {
    const identity = select.dataset.policyIdentity
    const fallback = select.dataset.policyDefault as KeyAction | undefined
    if (!identity) return
    if (fallback && select.value === fallback) delete policy.overrides[identity]
    else policy.overrides[identity] = select.value as KeyAction
  })
  return policy
}

function updateMappingSummary(): void {
  const rows = document.querySelectorAll('#keyPolicyMatrixBody tr').length
  el('mappingKeyboardSummary').textContent = `${rows}キー × ${modifierPatterns.length}パターン`
}

async function loadKeyMapping(): Promise<void> {
  const [mapping, policy] = await Promise.all([api.keyMapping(), api.overlayKeyPolicy()])
  renderKeyMapping(mapping, policy)
}

async function loadHelp(): Promise<void> {
  appInfo ??= await api.appInfo()
  el('helpVersion').textContent = `v${appInfo.version}`
  el('helpAuthor').textContent = appInfo.author
  el('helpGithubUrl').textContent = appInfo.github_url
  el('brandVersion').textContent = `v${appInfo.version}`
}

async function loadPage(page = activePage): Promise<void> {
  try {
    if (page === 'dashboard') await loadDashboard()
    else if (page === 'daily-ranking') await loadDailyRanking()
    else if (page === 'ranking') await loadRanking()
    else if (page === 'applications') await loadApplications()
    else if (page === 'matrix') await loadMatrix()
    else if (page === 'shortcut-detail') await loadShortcutDetail()
    else if (page === 'realtime-log') await loadRealtimeLog()
    else if (page === 'key-mapping') await loadKeyMapping()
    else if (page === 'excluded') await loadExcluded()
    else if (page === 'settings') await renderSettings()
    else if (page === 'help') await loadHelp()
  } catch (error) {
    showToast(errorMessage(error))
  }
}
function goPage(id: string): void {
  if (!(id in titles)) id = 'dashboard'
  activePage = id
  document.querySelectorAll<HTMLElement>('.page').forEach(page => page.classList.toggle('active', page.id === id))
  document.querySelectorAll<HTMLButtonElement>('.nav button[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === id))
  const rankingTree = el<HTMLDivElement>('rankingNavTree')
  rankingTree.classList.toggle('active', rankingPages.includes(id))
  if (rankingPages.includes(id)) rankingTree.classList.add('open')
  el('topTitle').textContent = titles[id] ?? 'ShortcutKeyCounter'
  void loadPage(id)
}

async function withButton(button: HTMLButtonElement, action: () => Promise<void>): Promise<void> {
  if (button.disabled) return
  const text = button.textContent
  button.disabled = true
  button.textContent = '処理中...'
  try { await action() } finally { button.disabled = false; button.textContent = text }
}

function bindEvents(): void {
  document.querySelectorAll<HTMLButtonElement>('.nav button').forEach(button => button.addEventListener('click', () => {
    if (button.dataset.page) goPage(button.dataset.page)
  }))
  el<HTMLButtonElement>('rankingNavToggle').addEventListener('click', () => el<HTMLDivElement>('rankingNavTree').classList.toggle('open'))
  el<HTMLInputElement>('dailyRankingDate').addEventListener('change', () => void loadDailyRanking())
  document.querySelectorAll<HTMLElement>('[data-page-range]').forEach(group => group.addEventListener('click', event => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>('button[data-range]')
    if (!button) return
    const page = group.dataset.pageRange
    if (!page || !(page in rangeState)) return
    group.querySelectorAll('button').forEach(node => node.classList.remove('active'))
    button.classList.add('active')
    rangeState[page] = button.dataset.range as RangeKey
    void loadPage(page)
  }))
  el<HTMLButtonElement>('captureBtn').addEventListener('click', async () => {
    const current = await api.captureStatus().catch(() => null)
    if (!current) return showToast('計測状態を取得できませんでした。')
    try {
      const status = await api.setCaptureEnabled(!current.enabled)
      renderCaptureStatus(status, await api.captureHealth())
      showToast(status.enabled ? '計測を再開しました。' : '計測を停止しました。この状態は再起動後には引き継がれません。')
    } catch (error) { showToast(errorMessage(error)) }
  })
  el<HTMLButtonElement>('showAllRanking').addEventListener('click', () => goPage('ranking'))
  el<HTMLSelectElement>('rankingAppFilter').addEventListener('change', () => void loadRanking())
  el<HTMLSelectElement>('shortcutSelect').addEventListener('change', () => void loadShortcutDetail())
  el<HTMLButtonElement>('addExclude').addEventListener('click', async () => {
    const input = el<HTMLInputElement>('excludeInput')
    const name = input.value.trim()
    if (!name) return showToast('実行ファイル名を入力してください。')
    try { renderExcluded(await api.addExcludedApp(name)); input.value = ''; showToast(`${name} を除外対象に追加しました。`) } catch (error) { showToast(errorMessage(error)) }
  })
  el<HTMLInputElement>('excludeInput').addEventListener('keydown', event => { if (event.key === 'Enter') el<HTMLButtonElement>('addExclude').click() })

  el<HTMLButtonElement>('exportDaily').addEventListener('click', event => void withButton(event.currentTarget as HTMLButtonElement, async () => {
    const result = await api.exportDaily(); showToast(`${result.path} を出力しました（${result.rows}行）。`, { label: 'フォルダーを開く', run: () => api.openParentFolder(result.path) })
  }).catch(error => showToast(errorMessage(error))))
  el<HTMLButtonElement>('exportEvents').addEventListener('click', event => void withButton(event.currentTarget as HTMLButtonElement, async () => {
    const result = await api.exportEvents(); showToast(`${result.path} を出力しました（${result.rows}行）。`, { label: 'フォルダーを開く', run: () => api.openParentFolder(result.path) })
  }).catch(error => showToast(errorMessage(error))))
  el<HTMLButtonElement>('backupDb').addEventListener('click', event => void withButton(event.currentTarget as HTMLButtonElement, async () => {
    const result = await api.backupDatabase(); showToast(`${result.path} を保存しました。`, { label: 'フォルダーを開く', run: () => api.openParentFolder(result.path) })
  }).catch(error => showToast(errorMessage(error))))

  const deleteModal = el<HTMLDivElement>('deleteModal')
  el<HTMLButtonElement>('deleteBtn').addEventListener('click', () => deleteModal.classList.add('show'))
  el<HTMLButtonElement>('cancelDelete').addEventListener('click', () => deleteModal.classList.remove('show'))
  el<HTMLButtonElement>('confirmDelete').addEventListener('click', async () => {
    try {
      const result = await api.deleteStatistics()
      cachedBounds = null
      deleteModal.classList.remove('show')
      showToast(`統計データを削除しました（詳細 ${result.events_deleted}件 / 日次 ${result.daily_deleted}件）。`)
      await loadDashboard()
    } catch (error) { showToast(errorMessage(error)) }
  })

  el<HTMLDivElement>('themeControl').addEventListener('click', async event => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>('button[data-theme]')
    const theme = button?.dataset.theme
    if (theme !== 'dark' && theme !== 'light') return
    applyTheme(theme)
    try {
      await renderSettings(await api.setTheme(theme))
      showToast(theme === 'light' ? 'ライトモードに切り替えました。' : 'ダークモードに切り替えました。')
    } catch (error) {
      showToast(errorMessage(error))
      await renderSettings().catch(() => undefined)
    }
  })

  el('autoStartSwitch').addEventListener('click', async () => {
    const target = !el('autoStartSwitch').classList.contains('on')
    try { await renderSettings(await api.setAutoStart(target)); showToast(`自動起動を${target ? '有効' : '無効'}にしました。`) } catch (error) { showToast(errorMessage(error)) }
  })
  el('overlaySwitch').addEventListener('click', async () => {
    const target = !el('overlaySwitch').classList.contains('on')
    try {
      await renderSettings(await api.setOverlayEnabled(target))
      showToast(`ショートカットオーバーレイを${target ? '有効' : '無効'}にしました。`)
    } catch (error) { showToast(errorMessage(error)) }
  })
  el('overlayPositionMode').addEventListener('click', event => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>('button[data-mode]')
    if (!button || !currentOverlaySettings) return
    el('overlayPositionMode').querySelectorAll('button').forEach(node => node.classList.remove('active'))
    button.classList.add('active')
    const auto = button.dataset.mode === 'auto'
    el('overlayPositionGrid').classList.toggle('is-auto', auto)
    el('overlayPositionGrid').querySelectorAll<HTMLButtonElement>('button[data-position]').forEach(node => { node.disabled = auto })
    void saveOverlaySettingsFromUi().catch(error => showToast(errorMessage(error)))
  })
  el('overlayPositionGrid').addEventListener('click', event => {
    const button = (event.target as HTMLElement).closest<HTMLButtonElement>('button[data-position]')
    if (!button || button.disabled) return
    el('overlayPositionGrid').querySelectorAll('button').forEach(node => node.classList.remove('active'))
    button.classList.add('active')
    void saveOverlaySettingsFromUi().catch(error => showToast(errorMessage(error)))
  })
  ;['overlayDisplayMode', 'overlayMonitorMode', 'overlayMonitorSelect', 'overlayMaxRows', 'overlayDuration', 'overlayEnterMs', 'overlayExitMs', 'overlayBackgroundColor'].forEach(id => {
    el(id).addEventListener('change', () => void saveOverlaySettingsFromUi().catch(error => showToast(errorMessage(error))))
  })
  ;['overlayEnterAnimation', 'overlayExitAnimation'].forEach(id => {
    el(id).addEventListener('change', () => void saveOverlaySettingsFromUi().catch(error => showToast(errorMessage(error))))
  })
  el<HTMLInputElement>('overlayBackgroundOpacity').addEventListener('input', event => {
    const value = Number((event.target as HTMLInputElement).value)
    el('overlayOpacityValue').textContent = `${value}%`
  })
  el<HTMLInputElement>('overlayBackgroundOpacity').addEventListener('change', () => void saveOverlaySettingsFromUi().catch(error => showToast(errorMessage(error))))
  el<HTMLInputElement>('overlayBackgroundColorPicker').addEventListener('input', event => {
    el<HTMLInputElement>('overlayBackgroundColor').value = (event.target as HTMLInputElement).value
  })
  el<HTMLInputElement>('overlayBackgroundColorPicker').addEventListener('change', () => void saveOverlaySettingsFromUi().catch(error => showToast(errorMessage(error))))
  el<HTMLInputElement>('overlayBackgroundColor').addEventListener('input', event => {
    const value = (event.target as HTMLInputElement).value
    if (/^#[0-9a-fA-F]{6}$/.test(value)) el<HTMLInputElement>('overlayBackgroundColorPicker').value = value
  })
  el<HTMLButtonElement>('openOverlayLabels').addEventListener('click', async () => {
    try { await api.openOverlayLabels() } catch (error) { showToast(errorMessage(error)) }
  })
  el<HTMLButtonElement>('openOverlayPolicy').addEventListener('click', async () => {
    try { await api.openOverlayPolicy() } catch (error) { showToast(errorMessage(error)) }
  })
  el<HTMLButtonElement>('openOverlayTheme').addEventListener('click', async () => {
    try { await api.openOverlayTheme() } catch (error) { showToast(errorMessage(error)) }
  })
  el<HTMLButtonElement>('openOverlayDesignFolder').addEventListener('click', async () => {
    try { await api.openOverlayDesignFolder() } catch (error) { showToast(errorMessage(error)) }
  })
  el<HTMLButtonElement>('reloadOverlayAssets').addEventListener('click', async () => {
    try { await api.reloadOverlayAssets(); showToast('オーバーレイのJSON/SVGを再読み込みしました。') }
    catch (error) { showToast(errorMessage(error)) }
  })

  const elevatedModal = el<HTMLDivElement>('elevatedModal')
  const elevatedSwitch = el('elevatedSwitch')
  const setElevatedBusy = (busy: boolean): void => { elevatedBusy = busy; elevatedSwitch.classList.toggle('busy', busy); elevatedSwitch.setAttribute('aria-busy', String(busy)) }
  elevatedSwitch.addEventListener('click', async () => {
    if (elevatedBusy) return
    if (!elevatedSwitch.classList.contains('on')) { elevatedModal.classList.add('show'); return }
    setElevatedBusy(true)
    showToast('管理者権限Captureを終了しています...')
    try { await renderSettings(await api.setCaptureElevated(false)); showToast('管理者権限モードを無効にしました。通常権限Captureは継続しています。') }
    catch (error) { showToast(errorMessage(error)) }
    finally { setElevatedBusy(false) }
  })
  el<HTMLButtonElement>('cancelElevated').addEventListener('click', () => { if (!elevatedBusy) elevatedModal.classList.remove('show') })
  el<HTMLButtonElement>('confirmElevated').addEventListener('click', async () => {
    if (elevatedBusy) return
    setElevatedBusy(true)
    showToast('管理者権限Captureへ接続しています...')
    try {
      await renderSettings(await api.setCaptureElevated(true))
      elevatedModal.classList.remove('show')
      showToast('管理者権限モードを有効にしました。通常権限Captureも継続しています。')
    } catch (error) {
      elevatedModal.classList.remove('show')
      await renderSettings().catch(() => undefined)
      showToast(errorMessage(error))
    } finally { setElevatedBusy(false) }
  })
  el<HTMLButtonElement>('openDataFolder').addEventListener('click', async () => {
    try { await api.openDataFolder() } catch (error) { showToast(errorMessage(error)) }
  })

  el<HTMLButtonElement>('clearRealtimeLog').addEventListener('click', async () => {
    await api.clearRealtimeLogs()
    realtimeEntries = []
    realtimeSequence = 0
    renderRealtimeLog()
    showToast('リアルタイムログ表示をクリアしました。')
  })

  el('keyPolicyMatrixBody').addEventListener('change', updateMappingSummary)
  el<HTMLButtonElement>('mappingEnableAll').addEventListener('click', () => {
    document.querySelectorAll<HTMLSelectElement>('#keyPolicyMatrixBody select.key-policy-select').forEach(select => { select.value = 'record_and_display_break' })
    updateMappingSummary()
  })
  el<HTMLButtonElement>('mappingDisableAll').addEventListener('click', () => {
    document.querySelectorAll<HTMLSelectElement>('#keyPolicyMatrixBody select.key-policy-select').forEach(select => { select.value = 'ignore' })
    updateMappingSummary()
  })
  el<HTMLButtonElement>('mappingReset').addEventListener('click', async () => {
    const mapping = await api.keyMapping()
    mapping.keyboard.forEach(entry => { entry.enabled = true })
    Object.keys(mapping.mouse).forEach(key => { mapping.mouse[key as keyof KeyMapping['mouse']] = true })
    renderKeyMapping(mapping, { version: 2, default_single_key: 'continue_display', default_shortcut: 'record_and_display_break', overrides: {} })
  })
  el<HTMLButtonElement>('mappingSave').addEventListener('click', event => void withButton(event.currentTarget as HTMLButtonElement, async () => {
    const mapping = await api.setKeyMapping(mappingFromUi())
    const policy = await api.setOverlayKeyPolicy(policyFromUi())
    renderKeyMapping(mapping, policy)
    showToast('キーマッピングを保存し、Captureへ即時反映しました。')
  }).catch(error => showToast(errorMessage(error))))
  el<HTMLButtonElement>('mappingExport').addEventListener('click', event => void withButton(event.currentTarget as HTMLButtonElement, async () => {
    const mapping = await api.setKeyMapping(mappingFromUi())
    const policy = await api.setOverlayKeyPolicy(policyFromUi())
    renderKeyMapping(mapping, policy)
    const result = await api.exportKeyMapping()
    showToast(`${result.path} を出力しました。`, { label: 'フォルダーを開く', run: () => api.openParentFolder(result.path) })
  }).catch(error => showToast(errorMessage(error))))

  el<HTMLButtonElement>('openGithub').addEventListener('click', async () => {
    try {
      await loadHelp()
      if (appInfo) await api.openExternalUrl(appInfo.github_url)
    } catch (error) { showToast(errorMessage(error)) }
  })
}

async function poll(): Promise<void> {
  if (polling) return
  polling = true
  try {
    await refreshCaptureStatus()
    if (['dashboard', 'daily-ranking', 'ranking', 'applications', 'shortcut-detail'].includes(activePage)) await loadPage(activePage)
    if (activePage === 'settings') await renderSettings()
  } finally { polling = false }
}

async function boot(): Promise<void> {
  bindEvents()
  await api.onCaptureStateChanged(() => { void refreshCaptureStatus(); if (activePage === 'settings') void renderSettings() })
  await api.onOverlayEnabledChanged(enabled => {
    setSwitch(el('overlaySwitch'), enabled)
    if (currentOverlaySettings) currentOverlaySettings.enabled = enabled
  })
  await api.onNavigatePage(page => goPage(page))
  await api.onRealtimeLogChanged(() => {
    if (activePage === 'realtime-log') void loadRealtimeLog().catch(error => showToast(errorMessage(error)))
  })
  const initialSettings = await api.settings().catch(() => null)
  if (initialSettings) applyTheme(initialSettings.theme)
  await refreshCaptureStatus()
  await loadHelp().catch(() => undefined)
  el<HTMLInputElement>('dailyRankingDate').value = todayText()
  const initialPage = window.__SHORTCUT_KEY_COUNTER_INITIAL_PAGE__
  if (initialPage && initialPage in titles) goPage(initialPage)
  else await loadDashboard()
  window.setInterval(() => void poll(), 5000)
}

void boot().catch(error => showToast(errorMessage(error)))
