//! System Trayと常駐動作。

use tauri::menu::{CheckMenuItem, Menu, MenuItem, PredefinedMenuItem};
use tauri::tray::TrayIconBuilder;
use tauri::{App, AppHandle, Emitter, Manager, Wry};

use crate::app_state::AppState;
use crate::window_manager::request_show_main_window;

pub struct TrayUiState {
    capture_item: MenuItem<Wry>,
    overlay_item: CheckMenuItem<Wry>,
}

pub fn setup_tray(app: &App) -> tauri::Result<()> {
    let open = MenuItem::with_id(app, "open", "ShortcutKeyCounter を開く", true, None::<&str>)?;
    let capture = MenuItem::with_id(app, "capture", "計測を停止", true, None::<&str>)?;
    let overlay_enabled = app
        .state::<AppState>()
        .overlay_enabled()
        .unwrap_or_else(|_| app.state::<AppState>().overlay.is_enabled());
    let overlay = CheckMenuItem::with_id(
        app,
        "overlay-toggle",
        "オーバーレイ表示",
        true,
        overlay_enabled,
        None::<&str>,
    )?;
    let separator = PredefinedMenuItem::separator(app)?;
    let quit = MenuItem::with_id(app, "quit", "終了", true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&open, &capture, &overlay, &separator, &quit])?;
    let capture_menu = capture.clone();
    let overlay_menu = overlay.clone();

    TrayIconBuilder::with_id("shortcut-key-counter-tray")
        .icon(tauri::include_image!("icons/32x32.png"))
        .tooltip("ShortcutKeyCounter - 計測中")
        .menu(&menu)
        .show_menu_on_left_click(false)
        .on_menu_event(move |app, event| match event.id.as_ref() {
            "open" => request_show_main_window(app),
            "capture" => {
                let state = app.state::<AppState>();
                if let Ok(enabled) = state.capture_enabled() {
                    if state.set_capture_enabled(!enabled).is_ok() {
                        sync_capture_ui(app, !enabled);
                    }
                }
            }
            "overlay-toggle" => {
                let state = app.state::<AppState>();
                if let Ok(current) = state.overlay_enabled() {
                    let next = !current;
                    if state.set_overlay_enabled(next).is_ok() {
                        sync_overlay_ui(app, next);
                    }
                }
            }
            "quit" => {
                app.state::<AppState>().mark_exiting();
                app.exit(0);
            }
            _ => {}
        })
        .build(app)?;

    app.manage(TrayUiState {
        capture_item: capture_menu,
        overlay_item: overlay_menu,
    });
    Ok(())
}

pub fn sync_overlay_ui(app: &AppHandle, enabled: bool) {
    if let Some(state) = app.try_state::<TrayUiState>() {
        let _ = state.overlay_item.set_checked(enabled);
    }
    let _ = app.emit("overlay-enabled-changed", enabled);
}

pub fn sync_capture_ui(app: &AppHandle, enabled: bool) {
    if let Some(state) = app.try_state::<TrayUiState>() {
        let _ = state.capture_item.set_text(if enabled {
            "計測を停止"
        } else {
            "計測を再開"
        });
    }
    if let Some(tray) = app.tray_by_id("shortcut-key-counter-tray") {
        let _ = tray.set_tooltip(Some(if enabled {
            "ShortcutKeyCounter - 計測中"
        } else {
            "ShortcutKeyCounter - 停止中"
        }));
    }
    // WebViewが存在する場合は即時反映。存在しない場合は次回生成時のstatus取得で同期する。
    let _ = app.emit("capture-state-changed", enabled);
}
