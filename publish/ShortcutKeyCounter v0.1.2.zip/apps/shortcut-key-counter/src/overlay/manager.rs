use std::collections::VecDeque;
use std::path::Path;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

use crossbeam_channel::{bounded, Receiver, Sender, TrySendError};
use resvg::tiny_skia;
use shortcut_common::overlay::OverlayPosition;
use shortcut_windows::overlay_window::{calculate_overlay_origin, OverlayWindow, Size, WorkArea};
use thiserror::Error;

use super::animation::{
    enter_transform, exit_transform, phase_at, progress, OverlayPhase, OverlayTiming,
};
use super::config::{
    initialize_overlay_files, load_labels, load_theme, save_theme_atomic, OverlayConfig,
    OverlayConfigError, OverlayDisplayMode, OverlayMonitorMode, OverlayPaths, OverlayPositionMode,
};
use super::event::{OverlayCaptureSource, OverlayEvent, OverlayInputKind};
use super::renderer::{OverlayRenderError, OverlayRenderer};

const OVERLAY_QUEUE_CAPACITY: usize = 64;
const SOURCE_DEDUP_WINDOW: Duration = Duration::from_millis(50);
const ANIMATION_FRAME: Duration = Duration::from_millis(16);
pub const SINGLE_KEY_SEQUENCE_GAP: Duration = Duration::from_millis(700);
pub const MAX_SINGLE_KEY_TOKENS: usize = 20;

#[derive(Debug, Error)]
pub enum OverlayError {
    #[error("overlay files could not be initialized: {0}")]
    Config(#[from] OverlayConfigError),
    #[error("overlay thread could not be started: {0}")]
    ThreadStart(#[source] std::io::Error),
}

#[derive(Clone)]
pub struct OverlayHandle {
    sender: Sender<OverlayCommand>,
    enabled: Arc<AtomicBool>,
    dropped: Arc<AtomicU64>,
    paths: Arc<OverlayPaths>,
}

impl OverlayHandle {
    pub fn try_show(&self, event: OverlayEvent) {
        if !self.enabled.load(Ordering::Acquire) {
            return;
        }
        if matches!(
            self.sender.try_send(OverlayCommand::Show(event)),
            Err(TrySendError::Full(_))
        ) {
            self.dropped.fetch_add(1, Ordering::Relaxed);
        }
    }

    pub fn set_enabled(&self, enabled: bool) {
        self.enabled.store(enabled, Ordering::Release);
        match self.sender.try_send(OverlayCommand::SetEnabled(enabled)) {
            Err(TrySendError::Full(command)) => {
                let _ = self.sender.send(command);
            }
            Ok(()) | Err(TrySendError::Disconnected(_)) => {}
        }
    }

    pub fn is_enabled(&self) -> bool {
        self.enabled.load(Ordering::Acquire)
    }

    pub fn reload_assets(&self) {
        match self.sender.try_send(OverlayCommand::ReloadAssets) {
            Err(TrySendError::Full(command)) => {
                let _ = self.sender.send(command);
            }
            Ok(()) | Err(TrySendError::Disconnected(_)) => {}
        }
    }

    pub fn settings_snapshot(&self) -> OverlayConfig {
        load_theme(&self.paths.theme_json)
    }

    pub fn save_settings(
        &self,
        config: &OverlayConfig,
    ) -> Result<OverlayConfig, OverlayConfigError> {
        let config = config.clone().sanitize();
        save_theme_atomic(&self.paths.theme_json, &config)?;
        self.reload_assets();
        Ok(config)
    }

    pub fn dropped_count(&self) -> u64 {
        self.dropped.load(Ordering::Relaxed)
    }

    pub fn labels_path(&self) -> &Path {
        &self.paths.labels_json
    }

    pub fn theme_path(&self) -> &Path {
        &self.paths.theme_json
    }

    pub fn policy_path(&self) -> &Path {
        &self.paths.policy_json
    }

    pub fn design_directory(&self) -> &Path {
        &self.paths.design_directory
    }
}

pub struct OverlayRuntime {
    sender: Sender<OverlayCommand>,
    join_handle: Option<JoinHandle<()>>,
}

impl OverlayRuntime {
    pub fn disabled(app_dir: &Path) -> (Self, OverlayHandle) {
        let (sender, receiver) = bounded(1);
        drop(receiver);
        let paths = Arc::new(OverlayPaths {
            theme_json: app_dir.join("overlay-theme.json"),
            labels_json: app_dir.join("overlay_key_labels.json"),
            policy_json: app_dir.join("overlay_key_policy.json"),
            design_directory: app_dir.join("overlay/default"),
        });
        let handle = OverlayHandle {
            sender: sender.clone(),
            enabled: Arc::new(AtomicBool::new(false)),
            dropped: Arc::new(AtomicU64::new(0)),
            paths,
        };
        (
            Self {
                sender,
                join_handle: None,
            },
            handle,
        )
    }

    pub fn start(app_dir: &Path, enabled: bool) -> Result<(Self, OverlayHandle), OverlayError> {
        let paths = Arc::new(initialize_overlay_files(app_dir)?);
        let (sender, receiver) = bounded(OVERLAY_QUEUE_CAPACITY);
        let enabled_state = Arc::new(AtomicBool::new(enabled));
        let dropped = Arc::new(AtomicU64::new(0));
        let thread_paths = Arc::clone(&paths);
        let thread_enabled = Arc::clone(&enabled_state);
        let join_handle = thread::Builder::new()
            .name("shortcut-overlay".to_owned())
            .spawn(move || run_overlay_thread(receiver, thread_paths, thread_enabled))
            .map_err(OverlayError::ThreadStart)?;

        let handle = OverlayHandle {
            sender: sender.clone(),
            enabled: enabled_state,
            dropped,
            paths,
        };
        Ok((
            Self {
                sender,
                join_handle: Some(join_handle),
            },
            handle,
        ))
    }

    pub fn stop(mut self) {
        self.shutdown();
    }

    fn shutdown(&mut self) {
        let _ = self.sender.send(OverlayCommand::Stop);
        if let Some(join_handle) = self.join_handle.take() {
            let _ = join_handle.join();
        }
    }
}

impl Drop for OverlayRuntime {
    fn drop(&mut self) {
        self.shutdown();
    }
}

#[derive(Debug)]
enum OverlayCommand {
    Show(OverlayEvent),
    SetEnabled(bool),
    ReloadAssets,
    Stop,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum OverlayRowKind {
    Shortcut,
    SingleKeySequence,
}

#[derive(Debug)]
pub struct OverlayItem {
    pub id: u64,
    pub kind: OverlayRowKind,
    pub tokens: Vec<String>,
    pub created_at: Instant,
    pub last_input_at: Instant,
    pub phase: OverlayPhase,
    move_started: Option<Instant>,
    move_rows: f32,
}

#[derive(Clone, Debug)]
struct RecentSourceEvent {
    identity: String,
    application: String,
    source: OverlayCaptureSource,
    captured_at: chrono::NaiveDateTime,
    received_at: Instant,
}

#[derive(Default)]
pub struct AutoPositionState {
    pub index: usize,
    pub active_position: Option<OverlayPosition>,
}

pub const AUTO_POSITIONS: [OverlayPosition; 9] = [
    OverlayPosition::TopLeft,
    OverlayPosition::TopCenter,
    OverlayPosition::TopRight,
    OverlayPosition::MiddleRight,
    OverlayPosition::BottomRight,
    OverlayPosition::BottomCenter,
    OverlayPosition::BottomLeft,
    OverlayPosition::MiddleLeft,
    OverlayPosition::Center,
];

impl AutoPositionState {
    pub fn begin_session(&mut self) -> OverlayPosition {
        if let Some(position) = self.active_position {
            return position;
        }
        let position = AUTO_POSITIONS[self.index % AUTO_POSITIONS.len()];
        self.active_position = Some(position);
        position
    }

    pub fn end_session(&mut self) {
        if self.active_position.take().is_some() {
            self.index = (self.index + 1) % AUTO_POSITIONS.len();
        }
    }

    pub fn cancel_session(&mut self) {
        self.active_position = None;
    }
}

fn run_overlay_thread(
    receiver: Receiver<OverlayCommand>,
    paths: Arc<OverlayPaths>,
    enabled_state: Arc<AtomicBool>,
) {
    let config = load_theme(&paths.theme_json);
    let labels = load_labels(&paths.labels_json);
    let Ok(mut renderer) = OverlayRenderer::load(&paths, config, labels) else {
        enabled_state.store(false, Ordering::Release);
        return;
    };
    let Ok(mut window) = OverlayWindow::create() else {
        enabled_state.store(false, Ordering::Release);
        return;
    };

    let mut items: VecDeque<OverlayItem> = VecDeque::new();
    let mut recent_sources: VecDeque<RecentSourceEvent> = VecDeque::new();
    let mut auto_position = AutoPositionState::default();
    let mut next_id = 1u64;
    let mut enabled = enabled_state.load(Ordering::Acquire);

    loop {
        window.pump_messages();
        let requested_enabled = enabled_state.load(Ordering::Acquire);
        if requested_enabled != enabled {
            enabled = requested_enabled;
            if !enabled {
                items.clear();
                recent_sources.clear();
                auto_position.cancel_session();
                window.hide();
            }
        }

        let now = Instant::now();
        let had_items_before = !items.is_empty();
        remove_expired(&mut items, now, renderer.config());
        if had_items_before && items.is_empty() {
            auto_position.end_session();
        }
        prune_source_dedup(&mut recent_sources, now);

        if enabled && !items.is_empty() {
            if render_frame(
                &mut window,
                &mut renderer,
                &mut items,
                now,
                &mut auto_position,
            )
            .is_err()
            {
                window.hide();
                enabled = false;
                enabled_state.store(false, Ordering::Release);
                items.clear();
                auto_position.cancel_session();
            }
        } else {
            window.hide();
        }

        let wait = next_wait_duration(&items, now, renderer.config());
        let command = if items.is_empty() {
            match receiver.recv() {
                Ok(command) => Some(command),
                Err(_) => break,
            }
        } else {
            match receiver.recv_timeout(wait) {
                Ok(command) => Some(command),
                Err(crossbeam_channel::RecvTimeoutError::Timeout) => None,
                Err(crossbeam_channel::RecvTimeoutError::Disconnected) => break,
            }
        };

        let Some(command) = command else { continue };
        match command {
            OverlayCommand::Show(event) => {
                if !enabled || is_duplicate_source_event(&recent_sources, &event) {
                    continue;
                }
                recent_sources.push_back(RecentSourceEvent {
                    identity: event.identity().to_owned(),
                    application: event.application.clone(),
                    source: event.source,
                    captured_at: event.occurred_at,
                    received_at: event.received_at,
                });
                if items.is_empty() && renderer.config().position_mode == OverlayPositionMode::Auto
                {
                    auto_position.begin_session();
                }
                let config = renderer.config().clone();
                push_item(&mut items, event, Instant::now(), &config, &mut next_id);
            }
            OverlayCommand::SetEnabled(value) => {
                enabled = value;
                enabled_state.store(value, Ordering::Release);
                if !value {
                    items.clear();
                    recent_sources.clear();
                    auto_position.cancel_session();
                    window.hide();
                }
            }
            OverlayCommand::ReloadAssets => {
                let config = load_theme(&paths.theme_json);
                let labels = load_labels(&paths.labels_json);
                let previous_mode = renderer.config().position_mode;
                if renderer.replace_assets(&paths, config, labels).is_ok() {
                    if renderer.config().position_mode == OverlayPositionMode::Fixed
                        || previous_mode != renderer.config().position_mode && items.is_empty()
                    {
                        auto_position.cancel_session();
                    }
                    enforce_max_rows(&mut items, renderer.config().max_rows);
                    if items.is_empty() {
                        window.hide();
                    }
                }
            }
            OverlayCommand::Stop => break,
        }
    }
    window.hide();
}

fn push_item(
    items: &mut VecDeque<OverlayItem>,
    event: OverlayEvent,
    now: Instant,
    config: &super::config::OverlayConfig,
    next_id: &mut u64,
) {
    let continuation_tokens = vec![event.display_key.clone()];
    if !event.display_break
        && append_or_create_continuation(items, continuation_tokens, now, *next_id)
    {
        if items.len() == 1 && items.back().is_some_and(|item| item.id == *next_id) {
            *next_id = next_id.wrapping_add(1);
        }
        return;
    }

    for item in items.iter_mut() {
        item.move_rows += 1.0;
        item.move_started = Some(now);
    }
    items.push_back(OverlayItem {
        id: *next_id,
        kind: if event.kind == OverlayInputKind::SingleKey {
            OverlayRowKind::SingleKeySequence
        } else {
            OverlayRowKind::Shortcut
        },
        tokens: if event.kind == OverlayInputKind::SingleKey {
            vec![event.display_key]
        } else {
            event.display_key.split('+').map(str::to_owned).collect()
        },
        created_at: now,
        last_input_at: now,
        phase: OverlayPhase::Entering,
        move_started: None,
        move_rows: 0.0,
    });
    *next_id = next_id.wrapping_add(1);
    enforce_max_rows(items, config.max_rows);
}

fn append_or_create_continuation(
    items: &mut VecDeque<OverlayItem>,
    tokens: Vec<String>,
    now: Instant,
    next_id: u64,
) -> bool {
    if let Some(last) = items.back_mut() {
        let can_append = last.kind == OverlayRowKind::SingleKeySequence
            && now.saturating_duration_since(last.last_input_at) <= SINGLE_KEY_SEQUENCE_GAP
            && last.tokens.len().saturating_add(tokens.len()) <= MAX_SINGLE_KEY_TOKENS;
        if can_append {
            last.tokens.extend(tokens);
            last.last_input_at = now;
            last.phase = OverlayPhase::Stable;
            return true;
        }
    }

    if items.is_empty() {
        items.push_back(OverlayItem {
            id: next_id,
            kind: OverlayRowKind::SingleKeySequence,
            tokens,
            created_at: now,
            last_input_at: now,
            phase: OverlayPhase::Entering,
            move_started: None,
            move_rows: 0.0,
        });
        return true;
    }
    false
}

/// 連続単独キーを既存の同一行へ追加する。追加できた場合はtrueを返す。
pub fn append_or_create_single_key(
    items: &mut VecDeque<OverlayItem>,
    key: String,
    now: Instant,
    next_id: u64,
) -> bool {
    append_or_create_continuation(items, vec![key], now, next_id)
}

pub fn enforce_max_rows(items: &mut VecDeque<OverlayItem>, max_rows: usize) {
    let max_rows = max_rows.clamp(1, 10);
    while items.len() > max_rows {
        items.pop_front();
    }
}

fn item_timing_origin(item: &OverlayItem) -> Instant {
    match item.kind {
        OverlayRowKind::Shortcut => item.created_at,
        OverlayRowKind::SingleKeySequence => item.last_input_at,
    }
}

fn remove_expired(
    items: &mut VecDeque<OverlayItem>,
    now: Instant,
    config: &super::config::OverlayConfig,
) {
    let timing = OverlayTiming::from_config(config);
    while items
        .front()
        .is_some_and(|item| phase_at(now, item_timing_origin(item), &timing).is_none())
    {
        items.pop_front();
    }
}

fn prune_source_dedup(recent: &mut VecDeque<RecentSourceEvent>, now: Instant) {
    while recent
        .front()
        .is_some_and(|entry| now.saturating_duration_since(entry.received_at) > SOURCE_DEDUP_WINDOW)
    {
        recent.pop_front();
    }
}

fn is_duplicate_source_event(recent: &VecDeque<RecentSourceEvent>, event: &OverlayEvent) -> bool {
    recent.iter().rev().any(|entry| {
        entry.source != event.source
            && entry.identity == event.identity()
            && entry.application.eq_ignore_ascii_case(&event.application)
            && event
                .occurred_at
                .signed_duration_since(entry.captured_at)
                .num_milliseconds()
                .abs()
                <= SOURCE_DEDUP_WINDOW.as_millis() as i64
    })
}

fn render_frame(
    window: &mut OverlayWindow,
    renderer: &mut OverlayRenderer,
    items: &mut VecDeque<OverlayItem>,
    now: Instant,
    auto_position: &mut AutoPositionState,
) -> Result<(), OverlayRenderError> {
    let config = renderer.config().clone();
    let (target_window, monitor) = match config.display_mode {
        OverlayDisplayMode::ActiveWindow => window
            .active_window_metrics()
            .map(|(target, metrics)| (Some(target), metrics))
            .map_err(|_| OverlayRenderError::PixmapAllocation)?,
        OverlayDisplayMode::Desktop => {
            let metrics = if config.monitor_mode == OverlayMonitorMode::Fixed
                && !config.fixed_monitor_id.is_empty()
            {
                window.fixed_monitor_metrics(&config.fixed_monitor_id)
            } else {
                window.active_monitor_metrics()
            }
            .map_err(|_| OverlayRenderError::PixmapAllocation)?;
            (None, metrics)
        }
    };
    window
        .set_display_target(
            target_window,
            config.display_mode == OverlayDisplayMode::Desktop,
        )
        .map_err(|_| OverlayRenderError::PixmapAllocation)?;
    let scale = monitor.scale();
    let gap = (config.item_gap_px.max(0) as f32 * scale).round() as u32;
    let key_height = (config.key.height as f32 * scale).round().max(1.0) as u32;
    let padding = (14.0 * scale).round().max(1.0) as u32;
    let animation_margin = (config.animation.slide_distance.abs() * scale).ceil() as u32 + 8;
    let step = key_height.saturating_add(gap);
    let stack_height = step
        .saturating_mul(items.len() as u32)
        .saturating_sub(if items.is_empty() { 0 } else { gap });

    let mut rendered = Vec::with_capacity(items.len());
    let mut row_width = 1u32;
    for item in items.iter() {
        let bitmap =
            renderer.render_row(&item.tokens, item.kind == OverlayRowKind::Shortcut, scale)?;
        row_width = row_width.max(bitmap.width());
        rendered.push(bitmap);
    }
    let max_width = (config.max_window_width as f32 * scale).round() as u32;
    let width = row_width
        .saturating_add(padding.saturating_mul(2))
        .min(max_width.max(1))
        .max(1);
    let height = stack_height
        .saturating_add(padding.saturating_mul(2))
        .saturating_add(animation_margin.saturating_mul(2))
        .max(1);
    let mut canvas =
        tiny_skia::Pixmap::new(width, height).ok_or(OverlayRenderError::PixmapAllocation)?;

    if let Some(path) = rounded_rect_path(width as f32, height as f32, 12.0 * scale) {
        let background = renderer.background_rgba();
        let mut paint = tiny_skia::Paint::default();
        paint.set_color(tiny_skia::Color::from_rgba8(
            background.r,
            background.g,
            background.b,
            background.a,
        ));
        canvas.fill_path(
            &path,
            &paint,
            tiny_skia::FillRule::Winding,
            tiny_skia::Transform::identity(),
            None,
        );
    }

    let timing = OverlayTiming::from_config(&config);
    for (index, (item, bitmap)) in items.iter_mut().zip(rendered.iter()).enumerate() {
        let origin = item_timing_origin(item);
        item.phase = phase_at(now, origin, &timing).unwrap_or(OverlayPhase::Fading);
        let transform = match item.phase {
            OverlayPhase::Entering => enter_transform(
                config.animation.enter,
                progress(now, origin, config.animation.enter_ms),
                config.animation.slide_distance,
                config.animation.start_scale,
            ),
            OverlayPhase::Stable => super::animation::Transform::identity(),
            OverlayPhase::Fading => exit_transform(
                config.animation.exit,
                progress(now, timing.exit_at(origin), config.animation.exit_ms),
                config.animation.slide_distance,
            ),
        };
        let move_offset = if let Some(started) = item.move_started {
            let move_progress = progress(now, started, config.animation.enter_ms);
            let remaining = 1.0 - ease_out_cubic(move_progress);
            if move_progress >= 1.0 {
                item.move_started = None;
                item.move_rows = 0.0;
                0.0
            } else {
                item.move_rows * step as f32 * remaining
            }
        } else {
            0.0
        };
        let final_y = animation_margin as f32
            + padding as f32
            + index as f32 * step as f32
            + transform.offset_y * scale
            + move_offset;
        let transformed_width = bitmap.width() as f32 * transform.scale;
        let x =
            ((width as f32 - transformed_width) / 2.0 + transform.offset_x * scale).round() as i32;
        let y = final_y.round() as i32;
        let paint = tiny_skia::PixmapPaint {
            opacity: transform.opacity.clamp(0.0, 1.0),
            quality: tiny_skia::FilterQuality::Bilinear,
            ..tiny_skia::PixmapPaint::default()
        };
        canvas.draw_pixmap(
            x,
            y,
            bitmap.as_ref().as_ref(),
            &paint,
            tiny_skia::Transform::from_scale(transform.scale, transform.scale),
            None,
        );
    }

    let position = resolve_position(&config, auto_position, true);
    let origin = calculate_overlay_origin(
        WorkArea {
            left: monitor.work_left,
            top: monitor.work_top,
            right: monitor.work_right,
            bottom: monitor.work_bottom,
        },
        Size {
            width: width as i32,
            height: height as i32,
        },
        position,
        (config.margin_px.max(0) as f32 * scale).round() as i32,
    );
    window
        .present_rgba(canvas.data(), width, height, origin.x, origin.y)
        .map_err(|_| OverlayRenderError::PixmapAllocation)?;
    Ok(())
}

pub fn resolve_position(
    config: &super::config::OverlayConfig,
    auto: &mut AutoPositionState,
    _has_items_before_event: bool,
) -> OverlayPosition {
    match config.position_mode {
        super::config::OverlayPositionMode::Fixed => config.fixed_position,
        super::config::OverlayPositionMode::Auto => auto.begin_session(),
    }
}

fn next_wait_duration(
    items: &VecDeque<OverlayItem>,
    now: Instant,
    config: &super::config::OverlayConfig,
) -> Duration {
    if items.is_empty() {
        return Duration::from_secs(60);
    }
    let timing = OverlayTiming::from_config(config);
    let mut animating = false;
    let mut nearest = Duration::from_secs(1);
    for item in items {
        let origin = item_timing_origin(item);
        match phase_at(now, origin, &timing) {
            Some(OverlayPhase::Entering) | Some(OverlayPhase::Fading) => animating = true,
            Some(OverlayPhase::Stable) => {}
            None => nearest = Duration::ZERO,
        }
        let next = if now < timing.stable_at(origin) {
            timing.stable_at(origin).saturating_duration_since(now)
        } else if now < timing.exit_at(origin) {
            timing.exit_at(origin).saturating_duration_since(now)
        } else {
            timing.remove_at(origin).saturating_duration_since(now)
        };
        nearest = nearest.min(next);
        if item.move_started.is_some() {
            animating = true;
        }
    }
    if animating {
        ANIMATION_FRAME.min(nearest.max(Duration::from_millis(1)))
    } else {
        nearest.max(Duration::from_millis(1))
    }
}

fn ease_out_cubic(value: f32) -> f32 {
    1.0 - (1.0 - value.clamp(0.0, 1.0)).powi(3)
}

fn rounded_rect_path(width: f32, height: f32, radius: f32) -> Option<tiny_skia::Path> {
    let radius = radius.min(width / 2.0).min(height / 2.0).max(0.0);
    let k = 0.552_284_8;
    let mut builder = tiny_skia::PathBuilder::new();
    builder.move_to(radius, 0.0);
    builder.line_to(width - radius, 0.0);
    builder.cubic_to(
        width - radius + radius * k,
        0.0,
        width,
        radius - radius * k,
        width,
        radius,
    );
    builder.line_to(width, height - radius);
    builder.cubic_to(
        width,
        height - radius + radius * k,
        width - radius + radius * k,
        height,
        width - radius,
        height,
    );
    builder.line_to(radius, height);
    builder.cubic_to(
        radius - radius * k,
        height,
        0.0,
        height - radius + radius * k,
        0.0,
        height - radius,
    );
    builder.line_to(0.0, radius);
    builder.cubic_to(
        0.0,
        radius - radius * k,
        radius - radius * k,
        0.0,
        radius,
        0.0,
    );
    builder.close();
    builder.finish()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::overlay::config::OverlayConfig;

    fn captured_at() -> chrono::NaiveDateTime {
        chrono::NaiveDate::from_ymd_opt(2026, 8, 16)
            .expect("date")
            .and_hms_milli_opt(11, 0, 0, 0)
            .expect("time")
    }

    fn event(kind: OverlayInputKind, key: &str, source: OverlayCaptureSource) -> OverlayEvent {
        OverlayEvent {
            display_key: key.to_owned(),
            normalized_shortcut: (kind == OverlayInputKind::Shortcut).then(|| key.to_owned()),
            application: "Code.exe".to_owned(),
            source,
            occurred_at: captured_at(),
            received_at: Instant::now(),
            kind,
            display_break: true,
        }
    }

    #[test]
    fn local_and_elevated_same_event_within_50ms_is_suppressed() {
        let now = Instant::now();
        let mut recent = VecDeque::new();
        recent.push_back(RecentSourceEvent {
            identity: "Ctrl+C".to_owned(),
            application: "Code.exe".to_owned(),
            source: OverlayCaptureSource::Local,
            captured_at: captured_at(),
            received_at: now,
        });
        let mut elevated = event(
            OverlayInputKind::Shortcut,
            "Ctrl+C",
            OverlayCaptureSource::Elevated,
        );
        elevated.application = "code.EXE".to_owned();
        elevated.occurred_at = captured_at() + chrono::Duration::milliseconds(20);
        assert!(is_duplicate_source_event(&recent, &elevated));
    }

    #[test]
    fn repeated_input_from_same_source_is_not_overlay_deduped() {
        let now = Instant::now();
        let mut recent = VecDeque::new();
        recent.push_back(RecentSourceEvent {
            identity: "Ctrl+C".to_owned(),
            application: "Code.exe".to_owned(),
            source: OverlayCaptureSource::Local,
            captured_at: captured_at(),
            received_at: now,
        });
        let local = event(
            OverlayInputKind::Shortcut,
            "Ctrl+C",
            OverlayCaptureSource::Local,
        );
        assert!(!is_duplicate_source_event(&recent, &local));
    }

    #[test]
    fn consecutive_single_keys_append_to_same_row() {
        let t0 = Instant::now();
        let mut items = VecDeque::new();
        assert!(append_or_create_single_key(&mut items, "A".into(), t0, 1));
        assert!(append_or_create_single_key(
            &mut items,
            "B".into(),
            t0 + Duration::from_millis(100),
            2
        ));
        assert_eq!(items.len(), 1);
        assert_eq!(items[0].tokens, vec!["A", "B"]);
    }

    #[test]
    fn shortcut_breaks_single_key_sequence() {
        let config = OverlayConfig::default();
        let mut items = VecDeque::new();
        let now = Instant::now();
        push_item(
            &mut items,
            event(
                OverlayInputKind::SingleKey,
                "A",
                OverlayCaptureSource::Local,
            ),
            now,
            &config,
            &mut 1,
        );
        push_item(
            &mut items,
            event(
                OverlayInputKind::Shortcut,
                "Ctrl+C",
                OverlayCaptureSource::Local,
            ),
            now + Duration::from_millis(100),
            &config,
            &mut 2,
        );
        push_item(
            &mut items,
            event(
                OverlayInputKind::SingleKey,
                "D",
                OverlayCaptureSource::Local,
            ),
            now + Duration::from_millis(200),
            &config,
            &mut 3,
        );
        assert_eq!(items.len(), 3);
        assert_eq!(items[0].tokens, vec!["A"]);
        assert_eq!(items[1].tokens, vec!["Ctrl", "C"]);
        assert_eq!(items[2].tokens, vec!["D"]);
    }

    #[test]
    fn auto_position_stays_fixed_during_session() {
        let mut state = AutoPositionState::default();
        let first = state.begin_session();
        let second = state.begin_session();
        assert_eq!(first, OverlayPosition::TopLeft);
        assert_eq!(second, OverlayPosition::TopLeft);
        state.end_session();
        assert_eq!(state.begin_session(), OverlayPosition::TopCenter);
    }

    #[test]
    fn max_rows_discards_oldest_logical_row_after_append() {
        let config = OverlayConfig {
            max_rows: 2,
            ..OverlayConfig::default()
        };
        let now = Instant::now();
        let mut items = VecDeque::new();
        let mut next_id = 1;
        for (key, offset) in [("A", 0), ("B", 1), ("C", 2)] {
            push_item(
                &mut items,
                event(
                    OverlayInputKind::Shortcut,
                    &format!("Ctrl+{key}"),
                    OverlayCaptureSource::Local,
                ),
                now + Duration::from_millis(offset),
                &config,
                &mut next_id,
            );
        }
        assert_eq!(items.len(), 2);
        assert_eq!(items.front().expect("oldest remaining").id, 2);
    }
}
