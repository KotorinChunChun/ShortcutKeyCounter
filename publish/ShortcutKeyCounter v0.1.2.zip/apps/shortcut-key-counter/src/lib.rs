//! UIから独立したcapture backend。

pub mod app_state;
pub mod capture_control;
pub mod capture_health;
pub mod capture_worker;
pub mod command_api;
pub mod command_error;
pub mod diagnostics;
pub mod elevated_capture;
pub mod exclusion_state;
pub mod maintenance;
pub mod runtime;
pub mod settings;
pub mod startup;
pub mod tauri_commands;
pub mod tray;

pub mod app_info;
pub mod key_mapping_state;
pub mod key_policy;
pub mod overlay;
pub mod realtime_log;
pub mod window_manager;
